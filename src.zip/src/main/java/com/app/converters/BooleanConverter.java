package com.app.converters;

import java.io.Serializable;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import org.springframework.stereotype.Component;
@Component("booleanConverter")
public class BooleanConverter implements Converter, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String arg2) {
	

		return null;

	}

	@Override
	public String getAsString(FacesContext context, UIComponent arg1, Object arg2) {
		if (arg2 == null || arg2.equals("")) {
			return "";
		}
		switch (arg2.toString()) {
		case "false":
			return "Non";
		case "true":
			return "Oui";
		}

		return "";

	}

}
