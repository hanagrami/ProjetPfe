package com.app.converters;

import java.io.Serializable;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import org.springframework.stereotype.Component;

@Component("etatUserConverter")
public class EtatUserConverter implements Converter, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public Object getAsObject(FacesContext arg0, UIComponent arg1, String arg2) {

		return arg2;
	}

	@Override
	public String getAsString(FacesContext arg0, UIComponent arg1, Object arg2) {
		if (arg2 == null || arg2.equals("")) {
			return "";
		}
		switch (arg2.toString()) {
		case "A":
			return "Actif";
		case "B":
			return "Bloque";
		case "S":
			return "Suspendu";
		case "I":
			return "Inactif";
		}

		return "";

	}

}
