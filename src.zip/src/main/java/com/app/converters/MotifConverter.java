package com.app.converters;

import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import java.io.Serializable;
import javax.faces.component.UIComponent;
import org.springframework.stereotype.Component;

@Component("motifConverter")
public class MotifConverter implements Converter, Serializable{
	private static final long serialVersionUID = 1L;
	
	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String arg2) {
	

		return null;

	}
	@Override
	public String getAsString(FacesContext context, UIComponent arg1, Object arg2) {
		if (arg2 == null || arg2.equals("")) {
			return "";
		}
		switch (arg2.toString()) {
		case "A":
			return "Autre";
		case "R":
			return "Fête religieuse";
		case "F":
			return "Fête Fixe";
		}

		return "";

	}

}
