package com.app.converters;

import java.io.Serializable;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.service.UserService;
import com.utils.JSFUtils;

@Component("nomPrenomAssureConverter")
public class NomPrenomAssureConverter implements Converter, Serializable {
	final static Logger logger = Logger.getLogger(NomPrenomAssureConverter.class);

	private static final long serialVersionUID = 1L;
	@Autowired
	UserService userService;

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		return null;

	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		try {

			if (value == null || value.equals("")) {
				return "";
			}
			return userService.findByMatriculeAss(value.toString()).orElse(null).getUsrNomprenom();
		} catch (Exception e) {
			logger.error("Erreur  ", e);
			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", ":form");
			return "";
		}

	}

}
