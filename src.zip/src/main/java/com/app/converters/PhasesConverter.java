package com.app.converters;

import java.io.Serializable;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.domain.Client;
import com.app.domain.Phase;
import com.app.service.PhaseService;

@Component("phconverter")
public class PhasesConverter implements Converter, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Autowired
	PhaseService phaseService;

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		// TODO Auto-generated method stub
		if (value == null || value.equals(""))
			return null;
		else
			return phaseService.findById(Integer.valueOf((Integer) value)).orElse(new Phase()).getNomPhase();
	}
}
