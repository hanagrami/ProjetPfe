package com.app.converters;

import java.io.Serializable;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.domain.Produit;
import com.app.service.ProduitService;
@Component("produitConveretor")
public class ProduitConverter implements Converter,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Autowired
	private ProduitService produitService;

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		// TODO Auto-generated method stub
		if(value==null||value.equals(""))
			return null;
		else
			return produitService.findById(Integer.valueOf((Integer) value)).orElse(new Produit()).getNomProduit();
	}
	}

