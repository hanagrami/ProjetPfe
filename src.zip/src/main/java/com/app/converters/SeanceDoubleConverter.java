package com.app.converters;

import java.io.Serializable;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import org.springframework.stereotype.Component;
@Component("seanceDoubleConverter")
public class SeanceDoubleConverter   implements Converter, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {

		return null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {

		if (value == null || value.equals("")) {
			return "";
		}
		switch (value.toString()) {
		case "false":
			return "Séance Unique";
		case "true":
			return "Séance Double";
		}

		return "";

	}

}
