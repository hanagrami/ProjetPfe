package com.app.converters;

import java.io.Serializable;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.service.UserService;
import com.utils.JSFUtils;

@Component("soldeCongeConverter")
public class SoldeCongeConverter implements Converter, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Autowired
	private UserService userService;

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		return null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		try {
			if (value == null || value.equals(""))
				return null;
			else

				return userService.findByIdentifiant(String.valueOf(value)).get().getSoldeConge().toString();

		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error("Erreur s est produite", e);
			return null;

		}

	}
}
