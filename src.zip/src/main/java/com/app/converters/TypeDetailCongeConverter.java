package com.app.converters;

import java.io.Serializable;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import org.springframework.stereotype.Component;

@Component("typeDetailCongeConverter")
public class TypeDetailCongeConverter implements Converter, Serializable {

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {

		return null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (value == null || value.equals(""))
			return "";

		switch (value.toString()) {
		case "C":
			return "Crédit";
		case "D":
			return "Débit";

		}
		return "";

	}

}
