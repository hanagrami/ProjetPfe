
package com.app.converters;

import java.io.Serializable;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.domain.Utilisateur;
import com.app.service.UserService;

@Component("utilisateurConverter")
public class UtilisateurConverter implements Converter, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Autowired
	UserService userService;

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		return null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (value == null || value.equals(""))
			return null;
		else
			return userService.findByIdentifiant(String.valueOf(value)).orElse(new Utilisateur()).getUsrNomprenom();
	}
}
