package com.app.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "CLIENT_H")
public class Client implements Serializable {
	/**
	* 
	*/
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "SEQUENCE")
	@SequenceGenerator(name = "SEQUENCE", sequenceName = "CLIHANA")
	private int idClient;
	private String nomClient;
	private String adresse;
	private String matriculeFiscale;
	private String rue;
	private String ville;
	private int codePostal;
	private int tel1;
	private int tel2;
	private int fax;
	private String email;
	private String statut;

}
