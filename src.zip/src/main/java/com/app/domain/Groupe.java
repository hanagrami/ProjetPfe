package com.app.domain;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@EqualsAndHashCode
@Table(name = "GROUPE")
public class Groupe {

	@Id
	@Column(name = "CODGRP", unique = true, nullable = false, length = 20)
	private String codgrp;
	private String libgrp;
	private String cutimod;
	private String cuticre;

	private LocalDateTime datecre;

	private LocalDateTime datemod;

}