package com.app.domain;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "HABILITATION")
public class Habilitations implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "codgrp", column = @Column(name = "CODGRP", nullable = false, length = 5)),
			@AttributeOverride(name = "idRessource", column = @Column(name = "ID_RESSOURCE", nullable = false, precision = 0)) })
	private HabilitationsId id;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CODGRP", nullable = false, insertable = false, updatable = false)
	private Groupe groupe;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "ID_RESSOURCE", nullable = false, insertable = false, updatable = false)
	private Ressources ressources;

}