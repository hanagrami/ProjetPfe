package com.app.domain;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;
@Data
@Entity
@Table(name = "PARAMETRAGE")
public class Parametrage implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	@Id	
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "SEQUENCE")
	@SequenceGenerator(name = "SEQUENCE", sequenceName = "PARAM_ID_SEQ")
	private int idParam;
	private String code;
	private String typeApp;
	private String categ;
	private String lib;
	private String valVar;
	private String cuticre;
	private LocalDateTime datecre;
	private String cutimod;
	private LocalDateTime datemod;
}