package com.app.domain;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "PHASE")
public class Phase implements Serializable {
	/**
	* 
	*/
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "sequence")
	@SequenceGenerator(name = "sequence", sequenceName = "PHASEHNAA")
	private int idPhase;
	private LocalDate commande;
	private LocalDate livraisonRecette;
	private LocalDate passageProd;
	private LocalDate receptionProvisoire;
	private LocalDate receptionDefinitive;
	private Integer idPhaseProjet;
	private String nomPhase;
	private Integer idMaintenance;
	private Integer flgmaint;
}
