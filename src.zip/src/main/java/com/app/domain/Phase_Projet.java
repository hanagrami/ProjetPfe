package com.app.domain;

import java.io.Serializable;
import java.sql.Blob;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "PHASE_PROJET")
public class Phase_Projet implements Serializable {
	/**
	* 
	*/
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "sequence")
	@SequenceGenerator(name = "sequence", sequenceName = "PHPROHNA")
	private int idPhaseProjet;
	private int idPhase;
	private String cutiCreePh;
	private String cutiModPh;
	private LocalDateTime dateCreePh;
	private LocalDateTime dateModPh;
	private float montantPhase;
	private LocalDate dateDebPhase;
	private LocalDate dateFinPhase;
	private String termePhase;
	private String etatPhase;
	private LocalDate datePhasePrevue;
	private int pourcentageMontantPhase;
	private Integer idMaintenance;
	private Integer idProjet;
	@Lob
	private byte[] pvPhase;
	

}
