package com.app.domain;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "PROJET")
public class Projet implements Serializable {
	/**
	* 
	*/
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "sequence")
	@SequenceGenerator(name = "sequence", sequenceName = "PROJHNAN")
	private int idProjet;
	private String nomProjet;
	private LocalDate dateDebProj;
	private LocalDate dateFinProj;

	// @JoinColumn(name = "id_phase", nullable = false, insertable = false,
	// updatable = false)
	// private Integer id_phase;
	private String usrMatricule;

	// @JoinColumn(name = "id_ressou", nullable = false, insertable = false,
	// updatable = false)
	// private Integer id_ressou;
	private String cutiCre;
	private String cutiMod;
	private LocalDateTime dateCre;
	private LocalDateTime dateMod;
	private Integer idClient;
	private Integer idProduit;
	private int chargeEstimativeProj;
	private int chargeValideProj;
	private int chargeGlobalProj;

}
