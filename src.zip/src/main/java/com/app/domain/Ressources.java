package com.app.domain;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
@Data
@Entity
@EqualsAndHashCode(exclude="habilitationses")
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "RESSOURCES")
public class Ressources implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	private Integer idRessource;
	private String lib;
	private String parent;
	private String url;
	private String icone;
	private String isMenu;
	private String type;
	private Integer ordre;
	private String action;
	private Boolean suspendu;
	private String securityRole;
	private String idLib;	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "ressources")
	private Set<Habilitations> habilitationses = new HashSet<Habilitations>(0);

}