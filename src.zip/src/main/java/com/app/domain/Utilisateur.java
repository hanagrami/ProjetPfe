package com.app.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.primefaces.model.StreamedContent;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "UTILISATEUR")
@EqualsAndHashCode(exclude = "groupe")
public class Utilisateur implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	private String usrMatricule;
	private String usermod;
	private String usercre;
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CODGRP")
	private Groupe groupe;
	private String usrNomprenom;
	private String usrMotdepasse;
	private String codeAff;
	private String matriculeDelta;
	private LocalDate dateRecrutement;
	private String tel_1;
	private String tel_2;
	private String mail_1;
	private String mail_2;
	private Boolean flgLov;
	private Boolean flgRegie;
	private Double salRegie;
	private String devise;
	private LocalDateTime datemod;
	private LocalDateTime datecre;
	private Long diplome;
	private Long grade;
	private Long codeFonction;
	private Long societe;
	private Long situationFam;
	private Integer nbEnfant;
	private LocalDate dateNaissance;
	private Boolean flgVal;
	private String flgStatut;
	private Boolean flgSuspendu;
	private Boolean flgCons;
	private BigDecimal soldeConge;
	private String matriculeAss;
	private Boolean flgPremConn;
	private Boolean flgAdm;
	private Integer nbErr;
	private String rib;
	private Long contrat;
	private LocalDate dateContrat;
	@Transient
	private BigDecimal tauxPresence;
	@Transient
	private BigDecimal cumulRetard;
	@Transient
	private long days, hours, minutes, seconds;
	@Transient
	private StreamedContent image;
}