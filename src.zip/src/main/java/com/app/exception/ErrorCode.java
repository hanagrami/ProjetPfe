package com.app.exception;

public interface ErrorCode {
	int getNumber();
}
