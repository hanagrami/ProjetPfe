package com.app.exception;

public enum ExcelParseCode implements ErrorCode {

	cellule_invalide(201), cellule_invalide_string(202), cellule_invalide_numeric(203), cellule_invalide_date(204),
	cellule_invalide_date_jour(205), cellule_matricule_invalide(206);

	private final int number;

	private ExcelParseCode(int number) {
		this.number = number;
	}

	@Override
	public int getNumber() {
		return number;
	}

}
