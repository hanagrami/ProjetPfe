package com.app.exception;

public enum GeneralErrorCode implements ErrorCode {

	RUNTIME_EXCPETION(1),
	erreur_produite(2);

	private final int number;

	private GeneralErrorCode(int number) {
		this.number = number;
	}

	@Override
	public int getNumber() {
		return number;
	}

}
