package com.app.java;

import java.sql.Connection;
import java.sql.SQLException;

import org.springframework.jdbc.core.support.AbstractSqlTypeValue;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import oracle.jdbc.OracleConnection;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AbstractTypeValue<T> extends AbstractSqlTypeValue {
	private T[] keyValueObjects;

	public static <T> AbstractTypeValue<T> forClass(Class<T> c,T[] keyValueObjects) {
		return new AbstractTypeValue<T>(keyValueObjects);
	}

	public static <T> AbstractTypeValue<T> forObject(T object,T[] keyValueObjects) {
		return new AbstractTypeValue<T>(keyValueObjects);
	}

	

	

	@Override
	protected Object createTypeValue(Connection con, int sqlType, String typeName) throws SQLException {
		
		ArrayDescriptor arrayDescriptor = new ArrayDescriptor(typeName,  con.unwrap(OracleConnection.class));
		return new ARRAY(arrayDescriptor,  con.unwrap(OracleConnection.class), keyValueObjects);
	}

}
