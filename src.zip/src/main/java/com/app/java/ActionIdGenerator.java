package com.app.java;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.Configurable;
import org.hibernate.id.IdentifierGenerator;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.type.Type;

public class ActionIdGenerator implements IdentifierGenerator, Configurable {

	@Override
	public void configure(Type type, Properties params, ServiceRegistry serviceRegistry) throws MappingException {
		// TODO Auto-generated method stub

	}

	@Override
	public Serializable generate(SharedSessionContractImplementor session, Object object) throws HibernateException {

		Connection connection = session.connection();

		try {

			Statement statement = connection.createStatement();

			ResultSet rs = statement.executeQuery("select TO_CHAR(SEQ_GESTION_CLIENT.nextval) from dual");

			if (rs.next()) {
				return rs.getString(1);
			}
		} catch (SQLException e) {
			return null;
		}

		return null;

	}

}
