package com.app.java;

public class CustomerContextHolder {
	/**
     * mysql
     */
    public static final String DATASOURCE = "dataSource";

    /**
     * oracle
     */
    public static final String DATASOURCE_1 = "dataSource1";
    
    /**
     * sql server
     */
    public static final String DATASOURCE_2 = "dataSource2";

    private static final ThreadLocal<String> contextHolder = new ThreadLocal<String>();

    public static void setCustomerType(String customerType) {
        contextHolder.set(customerType);
    }

    public static String getCustomerType() {
        return contextHolder.get();
    }

    public static void clearCustomerType() {
        contextHolder.remove();
    }
}
