package com.app.java;

public class InputProcedure<T> {

	private String nomParam;
	private String typeParam; // IN OUT INOUT
	private T valueParam;
	private Integer sqlType;
	private String objectTypeName; // TYPE OBJ INCASE sqlType STRUCT or ARRAY
	private Class classObjectType;
	private String arrayTypeName; // TYPE TAB INCASE sqlType ARRAY
	private T [] valueParamArray;
	
	
	public InputProcedure(String nomParam, String typeParam, T valueParam, Integer sqlType, String objectTypeName,
			Class classObjectType, String arrayTypeName,T [] valueParamArray) {
		super();
		this.nomParam = nomParam;
		this.typeParam = typeParam;
		this.valueParam = valueParam;
		this.sqlType = sqlType;
		this.objectTypeName = objectTypeName;
		this.classObjectType = classObjectType;
		this.arrayTypeName = arrayTypeName;
		this.valueParamArray = valueParamArray;
	}

	public String getNomParam() {
		return nomParam;
	}

	public void setNomParam(String nomParam) {
		this.nomParam = nomParam;
	}

	public String getTypeParam() {
		return typeParam;
	}

	public void setTypeParam(String typeParam) {
		this.typeParam = typeParam;
	}

	public T getValueParam() {
		return valueParam;
	}

	public void setValueParam(T valueParam) {
		this.valueParam = valueParam;
	}

	public Integer getSqlType() {
		return sqlType;
	}

	public void setSqlType(Integer sqlType) {
		this.sqlType = sqlType;
	}

	public String getObjectTypeName() {
		return objectTypeName;
	}

	public void setObjectTypeName(String objectTypeName) {
		this.objectTypeName = objectTypeName;
	}

	public Class getClassObjectType() {
		return classObjectType;
	}

	public void setClassObjectType(Class classObjectType) {
		this.classObjectType = classObjectType;
	}

	public String getArrayTypeName() {
		return arrayTypeName;
	}

	public void setArrayTypeName(String arrayTypeName) {
		this.arrayTypeName = arrayTypeName;
	}

	public T [] getValueParamArray() {
		return valueParamArray;
	}

	public void setValueParamArray(T [] valueParamArray) {
		this.valueParamArray = valueParamArray;
	}

}
