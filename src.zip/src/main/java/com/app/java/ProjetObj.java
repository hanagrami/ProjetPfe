package com.app.java;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ProjetObj {
	private Integer nombre_projet_p_en_ch;

	private Double pourcentage_projet_p_en_ch;

	private Integer nombre_projet_et_prev;

	private Double pourcentage_projet_et_prev;

	private Integer nombre_projet_valid;

	private Double pourcentage_projet_valid;

	private Integer nombre_projet_cloture;

	private Double pourcentage_projet_cloture;
}
