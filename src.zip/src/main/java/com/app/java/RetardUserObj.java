package com.app.java;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RetardUserObj {
	private String matricule;
	private String nom_prenom;
	private BigDecimal pourcentage;
}
