package com.app.java;

import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

public class SqlConsNonSaisiObj extends ConsNonSaisiObj implements SQLData  {

	@Override
	public String getSQLTypeName() throws SQLException {
		return "CONS_NON_SAISI_OBJ";
	}

	@Override
	public void readSQL(SQLInput stream, String typeName) throws SQLException {
		
	
		setMatricule(stream.readString());
		setDate_cons(stream.readDate());
		setCons_non_saisi(stream.readBigDecimal());
		setCons_saisi(stream.readBigDecimal());
		
	}

	@Override
	public void writeSQL(SQLOutput stream) throws SQLException {
		stream.writeString(getMatricule());
		stream.writeDate(getDate_cons());
		stream.writeBigDecimal(getCons_non_saisi());
		stream.writeBigDecimal(getCons_saisi());
		
	}

}
