package com.app.java;

import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

public class SqlPourcentagePresenceObj extends AssiduiteUserObj implements SQLData {

	@Override
	public String getSQLTypeName() throws SQLException {

		return "ASSIDUITE_USER_OBJ";
	}

	@Override
	public void readSQL(SQLInput stream, String typeName) throws SQLException {
		setMatricule(stream.readString());
		setNom_prenom(stream.readString());
		setPourcentage(stream.readBigDecimal());

	}

	@Override
	public void writeSQL(SQLOutput stream) throws SQLException {
		stream.writeString(getMatricule());
		stream.writeString(getNom_prenom());
		stream.writeBigDecimal(getPourcentage());

	}

}
