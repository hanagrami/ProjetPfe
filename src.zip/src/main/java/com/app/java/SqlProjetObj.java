package com.app.java;

import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

public class SqlProjetObj extends ProjetObj implements SQLData {

	@Override
	public String getSQLTypeName() throws SQLException {
		return "PROJET_OBJ";
	}

	@Override
	public void readSQL(SQLInput stream, String typeName) throws SQLException {
		setNombre_projet_cloture(stream.readInt());
		setNombre_projet_et_prev(stream.readInt());
		setNombre_projet_p_en_ch(stream.readInt());
		setNombre_projet_valid(stream.readInt());
		setPourcentage_projet_cloture(stream.readDouble());
		setPourcentage_projet_et_prev(stream.readDouble());
		setPourcentage_projet_p_en_ch(stream.readDouble());
		setPourcentage_projet_valid(stream.readDouble());
	}

	@Override
	public void writeSQL(SQLOutput stream) throws SQLException {
		stream.writeInt(getNombre_projet_cloture());
		stream.writeInt(getNombre_projet_et_prev());
		stream.writeInt(getNombre_projet_p_en_ch());
		stream.writeInt(getNombre_projet_valid());
		stream.writeDouble(getPourcentage_projet_cloture());
		stream.writeDouble(getPourcentage_projet_et_prev());
		stream.writeDouble(getPourcentage_projet_p_en_ch());
		stream.writeDouble(getPourcentage_projet_valid());

	}

}
