package com.app.java;

public enum TypeCongeEnum {

	INJECTION("Injection congé manuelle"), MANUELLE("Congé");

	private String abreviation;

	private TypeCongeEnum(String abreviation) {
		this.abreviation = abreviation;
	}

	public String getAbreviation() {
		return this.abreviation;
	}

}
