package com.app.java;

import java.math.BigDecimal;
import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UtilisateurConsomme {

	
	private String matricule;
	private BigDecimal nbrConsNonSaisi;
	private List<SqlConsNonSaisiObj> consNonSaisi;
}
