package com.app.java;

import java.math.BigDecimal;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class VirementData {

	private String ribDonneur;
	private String ribBeneficiaire;
	private String nomDonneur;
	private String nomBeneficiaire;
	private BigDecimal montant;
	private String motifOperation;
	private Date dateExecution;

}
