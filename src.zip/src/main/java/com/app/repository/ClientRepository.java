package com.app.repository;

import org.springframework.stereotype.Repository;

import com.app.domain.Client;
import com.repository.MyRepository;

@Repository
public interface ClientRepository extends MyRepository<Client, Integer> {

}
