package com.app.repository;

import org.springframework.stereotype.Repository;

import com.app.domain.Groupe;
import com.repository.MyRepository;

@Repository
public interface GroupeRepository extends MyRepository<Groupe, String> {

}
