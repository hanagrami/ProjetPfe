package com.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.app.domain.Groupe;
import com.app.domain.Habilitations;
import com.app.domain.HabilitationsId;
import com.repository.MyRepository;

@Repository
public interface HabiliationRepository extends MyRepository<Habilitations, HabilitationsId> {

	@Query("SELECT h FROM Habilitations h WHERE h.groupe = :grp")
    public List<Habilitations> findHabilitationByGrp(@Param("grp") Groupe grp);
	
	  public List<Habilitations> findHabilitationsByGroupeCodgrp(@Param("grp") String grp);
	
}
