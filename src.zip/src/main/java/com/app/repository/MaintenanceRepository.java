package com.app.repository;

import org.springframework.stereotype.Repository;

import com.app.domain.Maintenance;
import com.repository.MyRepository;

@Repository
public interface MaintenanceRepository extends MyRepository<Maintenance, Integer> {

}
