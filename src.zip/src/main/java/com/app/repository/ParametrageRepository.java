package com.app.repository;

import java.util.List;

import com.app.domain.Parametrage;
import com.repository.MyRepository;

public interface ParametrageRepository extends MyRepository<Parametrage, Integer> {

	List<Parametrage> findByCode(String code);
}
