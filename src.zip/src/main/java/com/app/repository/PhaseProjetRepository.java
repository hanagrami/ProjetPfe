package com.app.repository;

import java.util.List;

import org.springframework.stereotype.Repository;
import com.app.domain.Phase_Projet;
import com.repository.MyRepository;

@Repository
public interface PhaseProjetRepository extends MyRepository<Phase_Projet, Integer> {

	List<Phase_Projet> findByIdProjet(int idProjet);
}
