package com.app.repository;


import org.springframework.stereotype.Repository;

import com.app.domain.Phase;
import com.repository.MyRepository;

@Repository
public interface PhaseRepository extends MyRepository<Phase, Integer>{


}
