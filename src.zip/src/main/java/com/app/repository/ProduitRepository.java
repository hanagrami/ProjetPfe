package com.app.repository;

import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.app.domain.Produit;
import com.repository.MyRepository;

@Repository
public interface ProduitRepository extends MyRepository<Produit, Integer> {
	Optional<Produit> findByNomProduit(String nomProduit);
}
