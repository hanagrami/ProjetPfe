package com.app.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.app.domain.Phase_Projet;
import com.app.domain.Projet;
import com.app.domain.Projet_Ressource;
import com.repository.MyRepository;

@Repository
public interface ProjetRepository extends MyRepository<Projet, Integer> {
	public List<Projet> findByIdClient(int idClient);

	public List<Projet> findByIdProduit(int idProduit);
}
