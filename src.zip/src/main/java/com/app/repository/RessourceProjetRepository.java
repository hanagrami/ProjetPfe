package com.app.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.app.domain.Projet_Ressource;
import com.repository.MyRepository;

@Repository
public interface RessourceProjetRepository extends MyRepository<Projet_Ressource, Integer> {
	public List<Projet_Ressource> findByIdProjet(int idProjet);

}
