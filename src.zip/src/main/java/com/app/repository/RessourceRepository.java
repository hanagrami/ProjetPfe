package com.app.repository;

import org.springframework.stereotype.Repository;

import com.app.domain.Ressources;
import com.repository.MyRepository;

@Repository
public interface RessourceRepository extends MyRepository<Ressources, Integer>{

	
}
