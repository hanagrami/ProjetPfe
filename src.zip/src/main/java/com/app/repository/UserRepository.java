package com.app.repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.app.domain.Groupe;
import com.app.domain.Utilisateur;
import com.repository.MyRepository;

@Repository
public interface UserRepository extends MyRepository<Utilisateur, String> {

	public List<Utilisateur> findByGroupe(Groupe grp);

	public List<Utilisateur> findByFlgVal(Boolean flgVal);

	public Utilisateur findUtilisateurByusrMatricule(String usrMatricule);

	public List<Utilisateur> findByFlgCons(Boolean flgCons);

	public List<Utilisateur> findByflgStatutOrderBySoldeCongeDesc(String flgStatut);

	public List<Utilisateur> findByflgStatutOrderByUsrNomprenomAsc(String statut);

	public List<Utilisateur> findByUsrMatricule(String usrMatricule);

	public List<Utilisateur> findByFlgConsAndFlgStatut(Boolean flgCons, String statut);

	public List<Utilisateur> findByFlgRegie(Boolean flgRegie);

	public List<Utilisateur> findByUsrMatriculeAndFlgRegie(String usrMatricule, Boolean flgRegie);

	public List<Utilisateur> findByFlgStatutAndMatriculeAssNotNull(String flgStatut);

	public List<Utilisateur> findByFlgStatutAndMatriculeAssIsNull(String flgStatut);

	public Optional<Utilisateur> findByMatriculeAss(String matriculeAss);
	
	public List<Utilisateur> findByFlgStatutAndFlgRegie(String flgStatut,Boolean flgRegie);
	
	 public List<Utilisateur> findByFlgStatutIn(Collection<String> FlgStatuts);

	public List<Utilisateur> findByflgStatutOrderByUsrMatriculeAsc(String statut);

}
