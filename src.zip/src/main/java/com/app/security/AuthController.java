package com.app.security;

import java.io.IOException;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.WebAttributes;
import org.springframework.stereotype.Component;

import com.app.domain.Utilisateur;
import com.app.service.UserService;
import com.app.view.UserBean;

@Component("authController")
@Scope("session")
public class AuthController {

	@Autowired
	private UserService userService;

	protected final Log logger = LogFactory.getLog(getClass());

	/**
	 *
	 * Redirects the login request directly to spring security check. Leave this
	 * method as it is to properly support spring security.
	 * 
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String doLogin() throws ServletException, IOException {
		ExternalContext context = FacesContext.getCurrentInstance().getExternalContext();

		RequestDispatcher dispatcher = ((ServletRequest) context.getRequest())
				.getRequestDispatcher("/j_spring_security_check");//j spring security authentification relle doit 
		//etre mapper l'action de formulaire a ce servlet

		dispatcher.forward((ServletRequest) context.getRequest(), (ServletResponse) context.getResponse());

		FacesContext.getCurrentInstance().responseComplete();

		Exception ex = (Exception) FacesContext.getCurrentInstance().getExternalContext().getSessionMap()
				.get(WebAttributes.AUTHENTICATION_EXCEPTION);

		if (ex == null) {
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			if (!(authentication instanceof AnonymousAuthenticationToken)) {
				FacesContext fc = FacesContext.getCurrentInstance();
				UserBean userBean = fc.getApplication().evaluateExpressionGet(fc, "#{UserBean}", UserBean.class);
				Utilisateur utilisateur = userService.findByIdentifiant(authentication.getName()).get();

				if (!utilisateur.getFlgPremConn()) {
					userBean.chargerParametreGlobal(authentication.getName());
				}

			}
		} else {
			if (ex instanceof BadCredentialsException) {
				Object requestObj = context.getRequest();

				if (requestObj instanceof HttpServletRequest) {
					HttpServletRequest httpRequest = (HttpServletRequest) requestObj;
					userService.checkUserFailure(httpRequest.getParameter("j_username"));
				}
			}
		}
		return null;
	}

	public void updateMessages(boolean update) throws Exception {
		Exception ex = (Exception) FacesContext.getCurrentInstance().getExternalContext().getSessionMap()
				.get(WebAttributes.AUTHENTICATION_EXCEPTION);

		if (ex != null) {

			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, ex.getMessage(), ex.getMessage()));
		}
	}

	public void afterPhase(PhaseEvent event) {
	}

	public void beforePhase(PhaseEvent event) {
		Exception e = (Exception) FacesContext.getCurrentInstance().getExternalContext().getSessionMap()
				.get(WebAttributes.AUTHENTICATION_EXCEPTION);

		if (e instanceof BadCredentialsException) {
			logger.debug("Found exception in session map: " + e);
			FacesContext.getCurrentInstance().getExternalContext().getSessionMap()
					.put(WebAttributes.AUTHENTICATION_EXCEPTION, null);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Username or password not valid.", "Username or password not valid"));
		}
	}

	public PhaseId getPhaseId() {
		return PhaseId.RENDER_RESPONSE;

	}

}
