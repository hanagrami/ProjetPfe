package com.app.security;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.domain.Habilitations;
import com.app.domain.Utilisateur;
import com.app.repository.HabiliationRepository;
import com.app.service.UserService;

@Service("customUserDetailsService")//cette class recuperer les information des users 
public class CustomUserDetailsService implements UserDetailsService {

	@Autowired
	private UserService userService;

	@Autowired
	private HabiliationRepository habilitationRepository;
//loadUserByUsername auquel le nom d’utilisateur obtenu à partir de la page de 
	//connexion doit être passé et retourne le UserDetails correspondant.
	@Transactional(readOnly = true)
	public UserDetails loadUserByUsername(String ssoId) throws UsernameNotFoundException {
		Optional<Utilisateur> user = userService.findByIdentifiant(ssoId);
		if (!user.isPresent()) {
			throw new UsernameNotFoundException("Username not found");
		}

		return new org.springframework.security.core.userdetails.User(user.get().getUsrMatricule(), user.get().getUsrMotdepasse(),
				user.get().getFlgStatut().equals("A"), true, true, !user.get().getFlgSuspendu(), getGrantedAuthorities(user.get()));
	}

	private List<GrantedAuthority> getGrantedAuthorities(Utilisateur user) {
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		if (user.getFlgPremConn()) {
			authorities.add(new SimpleGrantedAuthority("ROLE_USER_PC"));
		}
		else  {
			authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
			List<Habilitations> listHabilitation = habilitationRepository
					.findHabilitationsByGroupeCodgrp(user.getGroupe().getCodgrp());

			for (int i = 0; i < listHabilitation.size(); i++) {

				if (listHabilitation.get(i).getRessources().getType().equals("ITEM")) {
					authorities
							.add(new SimpleGrantedAuthority(listHabilitation.get(i).getRessources().getSecurityRole()));
				}
			}
		}
		return authorities;
	}

}
