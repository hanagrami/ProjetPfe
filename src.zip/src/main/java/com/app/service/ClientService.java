package com.app.service;

import java.util.List;
import java.util.Optional;

import com.app.domain.Client;


public interface ClientService {
	public List<Client> findAll();

	public Optional<Client> findById(int idClient);

	public void saveClient(Client client);

	public void updateClient(Client client);

	public void deleteClient(Client client);
}

