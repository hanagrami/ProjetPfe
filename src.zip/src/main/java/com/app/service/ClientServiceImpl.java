package com.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.domain.Client;
import com.app.repository.ClientRepository;

@Service
public class ClientServiceImpl implements ClientService {

	@Autowired
	private ClientRepository clientRepository;

	@Override
	@Transactional(readOnly = true)
	public List<Client> findAll() {
		// TODO Auto-generated method stub
		return clientRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Optional<Client> findById(int idClient) {
		return clientRepository.findById(idClient);

	}

	@Override
	@Transactional
	public void saveClient(Client client) {
		// TODO Auto-generated method stub
		clientRepository.save(client);
	}

	@Override
	@Transactional(readOnly = false)
	public void updateClient(Client client) {
		// TODO Auto-generated method stub
		clientRepository.save(client);
	}

	@Override
	@Transactional
	public void deleteClient(Client client) {
		// TODO Auto-generated method stub
		clientRepository.delete(client);

	}

}
