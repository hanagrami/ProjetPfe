package com.app.service;

import java.util.List;
import java.util.Optional;

import com.app.domain.Groupe;
import com.app.domain.Ressources;

public interface GroupeService {

	public Optional<Groupe> findByCodeGroupe(String codeGrp);

	public void saveGroupe(Groupe grp,List<Ressources> listRessource);

	public void updateGroupe(Groupe grp,List<Ressources> listRessource);

	public void deleteGroupe(Groupe grp);

	public List<Groupe> findAll();
}
