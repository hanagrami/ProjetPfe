package com.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.domain.Groupe;
import com.app.domain.Habilitations;
import com.app.domain.HabilitationsId;
import com.app.domain.Ressources;
import com.app.repository.GroupeRepository;
import com.app.repository.HabiliationRepository;

@Service

public class GroupeServiceImpl implements GroupeService {

	@Autowired
	private GroupeRepository groupeRepository;

	@Autowired
	private HabiliationRepository habiliationRepository;

	@Override
	@Transactional(readOnly = true)
	public Optional<Groupe> findByCodeGroupe(String codeGrp) {

		return groupeRepository.findById(codeGrp);
	}

	@Override
	@Transactional
	public void saveGroupe(Groupe grp, List<Ressources> listRessource) {

		groupeRepository.save(grp);

		for (int i = 0; i < listRessource.size(); i++) {

			habiliationRepository.save(new Habilitations(new HabilitationsId(grp.getCodgrp(), listRessource.get(i).getIdRessource()),
							grp, listRessource.get(i)));

		}

	}

	@Override
	@Transactional
	public void updateGroupe(Groupe grp, List<Ressources> listRessource) {

		/* supprimer les anciennes habilitations */
		List<Habilitations> listHabilitionGroupe = habiliationRepository.findHabilitationByGrp(grp);

		for (int i = 0; i < listHabilitionGroupe.size(); i++) {
			habiliationRepository.deleteById(listHabilitionGroupe.get(i).getId());

		}
		/* ajouter les nouvelles habilitations */
		for (int i = 0; i < listRessource.size(); i++) {

			habiliationRepository
					.save(new Habilitations(new HabilitationsId(grp.getCodgrp(), listRessource.get(i).getIdRessource()),
							grp, listRessource.get(i)));

		}

		groupeRepository.save(grp);

	}

	@Override
	@Transactional
	public void deleteGroupe(Groupe grp) {

		List<Habilitations> listHabilitionGroupe = habiliationRepository.findHabilitationByGrp(grp);

		for (int i = 0; i < listHabilitionGroupe.size(); i++) {
			habiliationRepository.deleteById(listHabilitionGroupe.get(i).getId());

		}

		groupeRepository.delete(grp);
	}

	@Override
	@Transactional(readOnly = true)
	public List<Groupe> findAll() {

		return groupeRepository.findAll();

	}

}
