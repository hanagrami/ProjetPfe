package com.app.service;

import java.util.List;

import com.app.domain.Groupe;
import com.app.domain.Habilitations;
import com.app.domain.Ressources;

public interface HabilitationService {

	
	
	List<Habilitations> findHabilitationByGrp(Groupe grp);
	List<Ressources> findRessourceByGrp(Groupe grp);
}
