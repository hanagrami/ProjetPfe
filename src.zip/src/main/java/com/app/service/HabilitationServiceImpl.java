package com.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.domain.Groupe;
import com.app.domain.Habilitations;
import com.app.domain.Ressources;
import com.app.repository.HabiliationRepository;

@Service
@Transactional
public class HabilitationServiceImpl implements HabilitationService {

	@Autowired
	private HabiliationRepository habiliationRepository;

	@Override
	@Transactional(readOnly = true)
	public List<Habilitations> findHabilitationByGrp(Groupe grp) {

		return habiliationRepository.findHabilitationByGrp(grp);
	}

	@Override
	public List<Ressources> findRessourceByGrp(Groupe grp) {
		List<Habilitations> listHabilitation = habiliationRepository.findHabilitationByGrp(grp);

		List<Ressources> listRessources = new ArrayList<Ressources>();

		for (int i = 0; i < listHabilitation.size(); i++) {

			listRessources.add(listHabilitation.get(i).getRessources());
		}

		return listRessources;
	}

}
