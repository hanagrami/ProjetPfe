package com.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.domain.Maintenance;
import com.app.repository.MaintenanceRepository;

@Service
public class MaintenanceServiceImpl implements MaintenanceService {
	@Autowired
	private MaintenanceRepository maintenanceRepository;

	@Override
	@Transactional(readOnly = true)
	public List<Maintenance> findAll() {
		// TODO Auto-generated method stub
		return maintenanceRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Optional<Maintenance> findById(int idMaintenance) {
		// TODO Auto-generated method stub
		return maintenanceRepository.findById(idMaintenance);
	}

	@Override
	@Transactional
	public void saveMaint(Maintenance maintenance) {
		// TODO Auto-generated method stub
		maintenanceRepository.save(maintenance);
	}

	@Override
	@Transactional(readOnly = false)
	public void updateMaint(Maintenance maintenance) {
		// TODO Auto-generated method stub
		maintenanceRepository.save(maintenance);

	}

	@Override
	@Transactional
	public void deleteMaint(Maintenance maintenance) {
		// TODO Auto-generated method stub
		maintenanceRepository.delete(maintenance);
	}

}
