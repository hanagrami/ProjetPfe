package com.app.service;

import java.util.List;

import org.primefaces.model.menu.MenuModel;

import com.app.domain.Ressources;

public interface MenuFactoryService {
	public MenuModel buildTopMenu(List<Ressources> listDroitProfil);
}
