package com.app.service;

import java.util.Iterator;
import java.util.List;

import org.primefaces.model.menu.DefaultMenuItem;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.DefaultSubMenu;
import org.primefaces.model.menu.MenuModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.app.domain.Ressources;
import com.utils.JSFUtils;

@Service
@Transactional(readOnly = true)
public class MenuFactoryServiceImpl implements MenuFactoryService {

	/**
	 * 
	 */

	@Autowired
	private RessourceService ressourceService;

	private MenuModel menuBarModel;

	@Override
	public MenuModel buildTopMenu(List<Ressources> listDroitProfil) {

		List<Ressources> result;
		menuBarModel = new DefaultMenuModel();

		result = ressourceService.getRessourcesByQuery(null, null);
		Iterator<Ressources> iterator = result.iterator();

		while (iterator.hasNext()) {
			Ressources menu = (Ressources) iterator.next();
			if (isLeaf(menu.getIdRessource())) {

				if (listDroitProfil != null) {

					if (listDroitProfil.contains(menu)) {

						DefaultMenuItem item = new DefaultMenuItem();
						item.setValue(JSFUtils.getMessage(menu.getIdLib()));

						item.setIcon(menu.getIcone());
						item.setUpdate("mymenubar");
						item.setId(menu.getIdRessource().toString());
						if (menu.getAction() != null)
							item.setCommand(menu.getAction());
						else if (menu.getUrl() != null)
							item.setUrl(menu.getUrl());
						menuBarModel.getElements().add(item);
					}
				}

			} else {

				if (listDroitProfil != null) {

					if (listDroitProfil.contains(menu)) {

						DefaultSubMenu item = new DefaultSubMenu();
						item.setLabel(JSFUtils.getMessage(menu.getIdLib()));
						if (menu.getIcone() != null) {
							item.setIcon(menu.getIcone());
						}
						item.setId(menu.getIdRessource().toString());
						buildMenu(menu.getIdRessource(), item, listDroitProfil);
						menuBarModel.getElements().add(item);

						
					}
				}

			}

		}

		return menuBarModel;
	}

	private void buildMenu(Integer menuId, DefaultSubMenu node, List<Ressources> listDroitProfil) {

		List<Ressources> result;
		result = ressourceService.getRessourcesByQuery(menuId, null);
		Iterator<Ressources> iterator = result.iterator();

		while (iterator.hasNext()) {
			Ressources menu = (Ressources) iterator.next();

			if (isLeaf(menu.getIdRessource())) // simple menu
			{

				if (listDroitProfil != null) {

					if (listDroitProfil.contains(menu)) {

						DefaultMenuItem item = new DefaultMenuItem();
						item.setValue(JSFUtils.getMessage(menu.getIdLib()));

						item.setIcon(menu.getIcone());
						item.setUpdate("mymenubar");
						item.setId(menu.getIdRessource().toString());
						if (menu.getAction() != null)
							item.setCommand(menu.getAction());
						else if (menu.getUrl() != null)
							item.setUrl(menu.getUrl());
						node.getElements().add(item);

					}
				}

			} else {

				if (listDroitProfil != null) {

					if (listDroitProfil.contains(menu)) {

						DefaultSubMenu item = new DefaultSubMenu();
						item.setLabel(JSFUtils.getMessage(menu.getIdLib()));
						if (menu.getIcone() != null) {
							item.setIcon(menu.getIcone());
						}
						
						item.setId(menu.getIdRessource().toString());
						node.getElements().add(item);


						buildMenu(menu.getIdRessource(), item, listDroitProfil);

					}
				}

			}
		}
	}

	private boolean isLeaf(Integer menuId) {

		boolean isLeaf = false;

		List<Ressources> result;
		result = ressourceService.getRessourcesByQuery(menuId, null);

		if (result.size() == 0) {

			isLeaf = true;
		}

		else {

			isLeaf = false;
		}
		return isLeaf;
	}

	public MenuModel getMenuBarModel() {
		return menuBarModel;
	}

	public void setMenuBarModel(MenuModel menuBarModel) {
		this.menuBarModel = menuBarModel;
	}

}
