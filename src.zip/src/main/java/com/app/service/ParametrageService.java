package com.app.service;

import java.util.List;

import com.app.domain.Parametrage;

public interface ParametrageService {

	public Parametrage findByCode(String code);

	public void updateParametre(Parametrage param);
	
	public List<Parametrage> findAll();
}
