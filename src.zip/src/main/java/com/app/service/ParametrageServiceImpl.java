package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.domain.Parametrage;
import com.app.repository.ParametrageRepository;

@Service
public class ParametrageServiceImpl implements ParametrageService {

	@Autowired
	private ParametrageRepository parametrageRepository;

	@Override
	@Transactional(readOnly = true)
	public Parametrage findByCode(String code) {
		List<Parametrage> listPara = parametrageRepository.findByCode(code);
		if (listPara != null && listPara.size() > 0)
			return listPara.get(0);
		else
			return null;
	}

	@Override
	@Transactional
	public void updateParametre(Parametrage param) {

		parametrageRepository.save(param);

	}

	@Override
	@Transactional(readOnly = true)
	public List<Parametrage> findAll() {

		return parametrageRepository.findAll();
	}

}
