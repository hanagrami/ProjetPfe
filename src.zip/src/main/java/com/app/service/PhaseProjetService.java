package com.app.service;

import java.util.List;
import java.util.Optional;

import com.app.domain.Maintenance;
import com.app.domain.Phase;
import com.app.domain.Phase_Projet;

public interface PhaseProjetService {
	public List<Phase_Projet> findAll();

	public List<Phase_Projet> findByIdProjet(int idProjet);

	public void savePhp(Phase_Projet php);

	public void updatePhp(Phase_Projet php);

	public void deletePhp(Phase_Projet php);

	// public Optional<Phase_Projet> findById(int idPhaseProjet);
	public void save(Phase_Projet php, Maintenance maintenance);

}
