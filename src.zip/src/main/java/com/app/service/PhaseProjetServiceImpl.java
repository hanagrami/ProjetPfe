package com.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.domain.Maintenance;
import com.app.domain.Phase;
import com.app.domain.Phase_Projet;
import com.app.repository.MaintenanceRepository;
import com.app.repository.PhaseProjetRepository;
import com.app.repository.PhaseRepository;

@Service
public class PhaseProjetServiceImpl implements PhaseProjetService {
	@Autowired
	private PhaseProjetRepository phpRepository;
	@Autowired
	private MaintenanceRepository maintenanceRepository;
	@Autowired
	private PhaseRepository phaseRepository;

	@Override
	@Transactional(readOnly = true)
	public List<Phase_Projet> findAll() {
		// TODO Auto-generated method stub
		return phpRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public List<Phase_Projet> findByIdProjet(int idProjet) {
		// TODO Auto-generated method stub
		return phpRepository.findByIdProjet(idProjet);
	}

	@Override
	@Transactional
	public void savePhp(Phase_Projet php) {
		// TODO Auto-generated method stub
		phpRepository.save(php);
	}

	@Override
	@Transactional(readOnly = false)

	public void updatePhp(Phase_Projet php) {
		// TODO Auto-generated method stub
		phpRepository.save(php);
	}

	@Override
	@Transactional
	public void deletePhp(Phase_Projet php) {
		// TODO Auto-generated method stub
		phpRepository.delete(php);

	}

	@Override
	@Transactional
	public void save(Phase_Projet php, Maintenance maintenance) {
		// TODO Auto-generated method stub
		Phase p = phaseRepository.findById(php.getIdPhase()).get();
		if (p.getFlgmaint() == 1) {
			maintenanceRepository.save(maintenance);
			php.setIdMaintenance(maintenance.getIdMaintenance());
		}
	}

}
