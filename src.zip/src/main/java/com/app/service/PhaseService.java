package com.app.service;

import java.util.List;
import java.util.Optional;

import com.app.domain.Phase;


public interface PhaseService {
	public List<Phase> findAll();

	public Optional<Phase> findById(int idPhase);

	public void savePhase(Phase phase);

	public void updatePhase(Phase phase);

	public void deletePhase(Phase phase);
}
