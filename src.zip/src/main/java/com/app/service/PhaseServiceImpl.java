package com.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.domain.Phase;
import com.app.repository.PhaseRepository;

@Service
public class PhaseServiceImpl implements PhaseService {
	@Autowired
	private PhaseRepository phaseRepository;

	@Override
	@Transactional(readOnly = true)
	public List<Phase> findAll() {
		// TODO Auto-generated method stub
		return phaseRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Optional<Phase> findById(int idPhase) {
		// TODO Auto-generated method stub
		return  phaseRepository.findById(idPhase);
	}

	@Override
	@Transactional
	public void savePhase(Phase phase) {
		// TODO Auto-generated method stub
		phaseRepository.save(phase);
	}

	@Override
	@Transactional(readOnly = false)
	public void updatePhase(Phase phase) {
		// TODO Auto-generated method stub
		phaseRepository.save(phase);
	}

	@Override
	@Transactional
	public void deletePhase(Phase phase) {
		// TODO Auto-generated method stub
		phaseRepository.delete(phase);
	}

}
