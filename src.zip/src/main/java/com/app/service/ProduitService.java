package com.app.service;

import java.util.List;
import java.util.Optional;

import com.app.domain.Produit;

public interface ProduitService {
	public List<Produit> findAll();

	public Optional<Produit> findById(int idProduit);

	Optional<Produit> findByNomProduit(String nomProduit);

	public void saveProduit(Produit produit);

	public void updateProduit(Produit produit);

	public void deleteProduit(Produit produit);

}
