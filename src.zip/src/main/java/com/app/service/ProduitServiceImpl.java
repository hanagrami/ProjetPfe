package com.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.domain.Produit;
import com.app.repository.ProduitRepository;

@Service
public class ProduitServiceImpl implements ProduitService {
	@Autowired
	private ProduitRepository produitRepository;

	@Override
	@Transactional(readOnly = true)
	public List<Produit> findAll() {
		// TODO Auto-generated method stub
		return produitRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Optional<Produit> findById(int idProduit) {
		// TODO Auto-generated method stub
		return produitRepository.findById(idProduit);
	}

	@Override
	@Transactional
	public void saveProduit(Produit produit) {
		// TODO Auto-generated method stub
		produitRepository.save(produit);

	}

	@Override
	@Transactional(readOnly = false)
	public void updateProduit(Produit produit) {
		// TODO Auto-generated method stub
		produitRepository.save(produit);

	}

	@Override
	@Transactional
	public void deleteProduit(Produit produit) {
		// TODO Auto-generated method stub
		produitRepository.delete(produit);

	}

	@Override
	@Transactional(readOnly = true)
	public Optional<Produit> findByNomProduit(String nomProduit) {
		// TODO Auto-generated method stub
		return produitRepository.findByNomProduit(nomProduit);
		
	}

}
