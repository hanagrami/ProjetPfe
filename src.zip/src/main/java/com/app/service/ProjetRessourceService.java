package com.app.service;

import java.util.List;

import com.app.domain.Projet_Ressource;

public interface ProjetRessourceService {
	public List<Projet_Ressource> findAll();

	//public Optional<Projet_Ressource> findById(int id_ressou);
	
	List<Projet_Ressource> findByIdProjet(int idProjet);

	public void saveProjetRess(Projet_Ressource projetR);

	public void updateProjetRess(Projet_Ressource projetR);

	public void deleteProjetRess(Projet_Ressource projetR);

	// public List<Projet_Ressource> findRessourceByProjet(Projet projet);

}
