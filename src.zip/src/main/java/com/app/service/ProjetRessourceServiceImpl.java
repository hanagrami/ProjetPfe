package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.domain.Projet_Ressource;
import com.app.repository.RessourceProjetRepository;

@Service
public class ProjetRessourceServiceImpl implements ProjetRessourceService {
	@Autowired
	private RessourceProjetRepository ressourceprojetRepository;

	@Override
	@Transactional(readOnly = true)
	public List<Projet_Ressource> findAll() {
		// TODO Auto-generated method stub
		return ressourceprojetRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public List<Projet_Ressource> findByIdProjet(int idProjet) {
		// TODO Auto-generated method stub
		return ressourceprojetRepository.findByIdProjet(idProjet);
	}

	@Override
	@Transactional
	public void saveProjetRess(Projet_Ressource projetR) {
		// TODO Auto-generated method stub
		ressourceprojetRepository.save(projetR);
	}

	@Override
	@Transactional(readOnly = false)
	public void updateProjetRess(Projet_Ressource projetR) {
		// TODO Auto-generated method stub
		ressourceprojetRepository.save(projetR);
	}

	@Override
	@Transactional
	public void deleteProjetRess(Projet_Ressource projetR) {
		// TODO Auto-generated method stub
		ressourceprojetRepository.delete(projetR);
	}

	// @Override
	// public List<Projet_Ressource> findRessourceByProjet(Projet projet) {
	// TODO Auto-generated method stub
	// return ressourceprojetRepository.findRessourceByProjet(projet);
	// }

}
