package com.app.service;

import java.util.List;
import java.util.Optional;

import com.app.domain.Phase_Projet;
import com.app.domain.Projet;
import com.app.domain.Projet_Ressource;

public interface ProjetService {
	public List<Projet> findAll();

	public Optional<Projet> findById(int idProjet);

	public void ajoutProjet(Projet projet, List<Projet_Ressource> listeresspro, List<Phase_Projet> listephpro);

	public void saveProjet(Projet projet);

	public void updateProjet(Projet projet);

	public void deleteProjet(Projet projet);

	public void modifierprojet(Projet projet, List<Projet_Ressource> listeresspro, List<Phase_Projet> listephpro);

	public void deletprojet(Projet projet, List<Projet_Ressource> listeresspro, List<Phase_Projet> listephpro);

	public List<Projet> findByIdClient(int idClient);

	public List<Projet> findByIdProduit(int idProduit);
}
