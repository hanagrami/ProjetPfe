package com.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.domain.Habilitations;
import com.app.domain.HabilitationsId;
import com.app.domain.Phase_Projet;
import com.app.domain.Projet;
import com.app.domain.Projet_Ressource;
import com.app.repository.PhaseProjetRepository;
import com.app.repository.ProjetRepository;
import com.app.repository.RessourceProjetRepository;

@Service
public class ProjetServiceImpl implements ProjetService {
	@Autowired
	private ProjetRepository projetRepository;
	@Autowired
	private RessourceProjetRepository ressourceProjetRepository;
	@Autowired
	private PhaseProjetRepository phaseProjetRepository;

	@Override
	@Transactional(readOnly = true)
	public List<Projet> findAll() {
		// TODO Auto-generated method stub
		return projetRepository.findAll();
	}

	@Transactional(readOnly = true)
	public Optional<Projet> findById(int idProjet) {
		// TODO Auto-generated method stub
		return projetRepository.findById(idProjet);
	}

	@Override
	@Transactional
	public void saveProjet(Projet projet) {
		// TODO Auto-generated method stub
		projetRepository.save(projet);
	}

	@Override
	@Transactional(readOnly = false)
	public void updateProjet(Projet projet) {
		// TODO Auto-generated method stub
		projetRepository.save(projet);
	}

	@Override
	@Transactional
	public void deleteProjet(Projet projet) {
		// TODO Auto-generated method stub
		projetRepository.delete(projet);

	}

	@Override
	@Transactional
	public void ajoutProjet(Projet projet, List<Projet_Ressource> listeresspro, List<Phase_Projet> listephpro) {
		// TODO Auto-generated method stub
		Projet p = projetRepository.save(projet);
		p.getIdProjet();

		listeresspro.forEach(a -> {
			a.setIdProjet(p.getIdProjet());
		});
		ressourceProjetRepository.saveAll(listeresspro);

		listephpro.forEach(a -> {
			a.setIdProjet(p.getIdProjet());
		});
		phaseProjetRepository.saveAll(listephpro);
	}

	@Override
	@Transactional(readOnly = false)
	public void modifierprojet(Projet projet, List<Projet_Ressource> listeresspro, List<Phase_Projet> listephpro) {

		// TODO Auto-generated method stub
		Projet p = projetRepository.save(projet);
		p.getIdProjet();

		listeresspro.forEach(a -> {
			a.setIdProjet(p.getIdProjet());
		});
		ressourceProjetRepository.saveAll(listeresspro);

		listephpro.forEach(a -> {
			a.setIdProjet(p.getIdProjet());
		});
		phaseProjetRepository.saveAll(listephpro);

	}

	@SuppressWarnings("unlikely-arg-type")
	@Override
	@Transactional
	public void deletprojet(Projet projet, List<Projet_Ressource> listeresspro, List<Phase_Projet> listephpro) {
		// TODO Auto-generated method stub
		 projetRepository.delete(projet);;
	
		listeresspro.forEach(a -> {
			a.setIdProjet(projet.getIdProjet());
		});
		ressourceProjetRepository.deleteAll(listeresspro);


		listephpro.forEach(b -> {
			b.setIdProjet(projet.getIdProjet());
		});
		ressourceProjetRepository.deleteAll(listeresspro);
	}
	

	@Override
	public List<Projet> findByIdClient(int idClient) {
		// TODO Auto-generated method stub
		return projetRepository.findByIdClient(idClient);
	}

	@Override
	public List<Projet> findByIdProduit(int idProduit) {
		// TODO Auto-generated method stub
		return projetRepository.findByIdProduit(idProduit);
	}

}
