package com.app.service;

import java.util.List;
import java.util.Optional;

import com.app.domain.Ressources;

public interface RessourceService {

	public Optional<Ressources> findById(Integer idRessource);

	public List<Ressources> getRessourcesByQuery(Integer idRessourceParent, String type);

}
