package com.app.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.domain.Ressources;
import com.app.repository.RessourceRepository;

@Service

public class RessourceServiceImpl implements RessourceService {

	@Autowired
	private RessourceRepository ressourcesRepository;

	@Override
	@Transactional(readOnly = true)
	public Optional<Ressources> findById(Integer idRessource) {

		return ressourcesRepository.findById(idRessource);
	}

	@Override
	@Transactional(readOnly = true)
	public List<Ressources> getRessourcesByQuery(Integer idRessourceParent, String type) {

		List<Object> paramList = new ArrayList<Object>();
		String query = "";

		if (idRessourceParent == null)
			query = "select * from ressources t where t.is_menu='1' and t.parent is null ";
		else {
			query = "select * from ressources t where t.parent = ?";
			paramList.add(idRessourceParent);
		}
		if (type == null)
			query = query + " and t.suspendu =0 order by t.ordre asc";
		else {
			query = query + " and t.type = ? and t.suspendu =0  order by t.ordre asc";
			paramList.add(type);
		}

		return ressourcesRepository.findByQuery(query, paramList, Ressources.class);
	}

}
