package com.app.service;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.domain.Groupe;
import com.app.domain.Utilisateur;
import com.app.repository.ParametrageRepository;
import com.app.repository.UserRepository;

@Service

public class UserServiceImpl implements UserService {
	final static Logger logger = Logger.getLogger(UserServiceImpl.class);

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ParametrageRepository parametrageRepository;

	 

 

	@Override
	@Transactional(readOnly = true)
	public Optional<Utilisateur> findByIdentifiant(String identifiant) {
		return userRepository.findById(identifiant);
	}

	@Override
	@Transactional(readOnly = false)
	public void updateUser(Utilisateur user) {
		userRepository.save(user);

	}

	@Override
	@Transactional
	public void deleteUser(Utilisateur user) {
		userRepository.delete(user);
	}

	@Override
	@Transactional(readOnly = true)
	public List<Utilisateur> findByGroupe(Groupe grp) {
		return userRepository.findByGroupe(grp);
	}

	@Override
	@Transactional(readOnly = true)
	public List<Utilisateur> findAll() {
		return userRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public List<Utilisateur> findByFlgVal(Boolean flgVal) {
		return userRepository.findByFlgVal(flgVal);

	}

	@Override
	@Transactional
	public void checkUserFailure(String name) {
		Optional<Utilisateur> result = userRepository.findById(name);

		if (result.isPresent()) {
			Utilisateur user = result.get();

			if (user != null) {

				Integer nbTentative = Integer
						.valueOf(parametrageRepository.findByCode("NB_FAILURE_MAX").get(0).getValVar().toString());

				Integer nbrErr = user.getNbErr();
				if (nbrErr != null && nbrErr != 0 && nbrErr < nbTentative) {

					user.setNbErr(nbrErr + 1);

					if (user.getNbErr() >= nbTentative) {

						user.setFlgSuspendu(Boolean.TRUE);
					}

				} else if (nbrErr == null || nbrErr == 0) {

					user.setNbErr(1);

				} else if (nbrErr == nbTentative) {
					user.setFlgSuspendu(Boolean.TRUE);
				}

				userRepository.save(user);
			}
		}
	}

	@Override
	public List<Utilisateur> findByFlgCons(Boolean flgCons) {

		return userRepository.findByFlgCons(flgCons);
	}

	@Override
	public List<Utilisateur> findByflgStatut(String flgStatut) {
		return userRepository.findByflgStatutOrderBySoldeCongeDesc(flgStatut);
	}

	@Override
	public List<Utilisateur> findByflgStatutOrderByUsrNomprenomAsc(String statut) {

		return userRepository.findByflgStatutOrderByUsrNomprenomAsc(statut);
	}
	
	
	@Override
	public List<Utilisateur> findByflgStatutOrderByUsrMatriculeAsc(String statut) {

		return userRepository.findByflgStatutOrderByUsrMatriculeAsc(statut);
	}

	@Override
	public List<Utilisateur> findByUsrMatricule(String usrMatricule) {
		return userRepository.findByUsrMatricule(usrMatricule);
	}

	@Override
	public Utilisateur findOneByUsrMatricule(String usrMatricule) {
		return userRepository.findUtilisateurByusrMatricule(usrMatricule);
	}

	@Override
	public List<Utilisateur> findByFlgConsAndFlgStatut(Boolean flgCons, String statut) {
		return userRepository.findByFlgConsAndFlgStatut(flgCons, statut);
	}

	@Override
	public List<Utilisateur> findByFlgRegie(Boolean flgRegie) {
		return userRepository.findByFlgRegie(flgRegie);
	}

	@Override
	public List<Utilisateur> findByUsrMatriculeAndFlgRegie(String usrMatricule, Boolean flgRegie) {
		return userRepository.findByUsrMatriculeAndFlgRegie(usrMatricule, flgRegie);
	}

	@Override
	public List<Utilisateur> findByFlgStatutAndMatriculeAssNotNull(String flgStatut) {
		return userRepository.findByFlgStatutAndMatriculeAssNotNull(flgStatut);
	}

	@Override
	public List<Utilisateur> findByFlgStatutAndMatriculeAssIsNull(String flgStatut) {
		return userRepository.findByFlgStatutAndMatriculeAssIsNull(flgStatut);
	}

	@Override
	@Transactional(readOnly = true)
	public Optional<Utilisateur> findByMatriculeAss(String matriculeAss) {
		return userRepository.findByMatriculeAss(matriculeAss);
	}

	@Override
	@Transactional(readOnly = true)
	public List<Utilisateur> findByFlgStatutAndFlgRegie(String flgStatut, Boolean flgRegie) {
		return userRepository.findByFlgStatutAndFlgRegie(flgStatut, flgRegie);
	}

	@Override
	public List<Utilisateur> findByFlgStatutIn(Collection<String> FlgStatuts) {

		return userRepository.findByFlgStatutIn(FlgStatuts);
	}
 

	
}
