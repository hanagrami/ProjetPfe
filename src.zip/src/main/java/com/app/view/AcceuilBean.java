package com.app.view;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.app.domain.Client;
import com.app.domain.Phase_Projet;
import com.app.domain.Produit;
import com.app.domain.Projet;
import com.app.service.ClientService;
import com.app.service.ParametrageService;
import com.app.service.PhaseProjetService;
import com.app.service.ProduitService;
import com.app.service.ProjetService;

import lombok.Getter;
import lombok.Setter;

@Component("acceuilBean")
@Scope("view")
@Getter
@Setter
public class AcceuilBean implements Serializable {
	final static Logger logger = Logger.getLogger(AcceuilBean.class);
	private static final long serialVersionUID = 1L;

	@Autowired
	private ParametrageService parametrageService;
	@Autowired
	private ClientService clientservice;
	private Client client;
	private List<Projet> listepr = new ArrayList<Projet>();
	@Autowired
	ProjetService projetService;
	@Autowired
	private PhaseProjetService phaseprojetService;

	LocalDate currentdate = LocalDate.now();
	private Projet projet;
	private List<Projet> projets;
	private List<Phase_Projet> listphpro;

	@Autowired
	private ProduitService produitservice;
	private Produit produit;

	private int nbproduits = 0;
	private int nbprojclotu = 0;
	private int nbclients = 0;
	private LocalDate currentDate = LocalDate.now();
	private int nbprojencours = 0;
	private int nbphasencours;
	private int nbphasecloturé;

	@PostConstruct
	public void init() {
		nbclients = clientservice.findAll().size();
		nbproduits = produitservice.findAll().size();
		projets = projetService.findAll();
		projets.forEach(a -> {
			if (a.getDateFinProj().isBefore(currentDate)) {
				nbprojclotu++;
			}
		});

		projets.forEach(b -> {
			if (b.getDateDebProj().isBefore(currentDate) && b.getDateFinProj().isAfter(currentDate)
					|| b.getDateDebProj().isEqual(currentDate) && b.getDateFinProj().isAfter(currentDate)) {
				nbprojencours++;
			}
		});

		listphpro = phaseprojetService.findAll();
		listphpro.forEach(ph -> {
	
			if (ph.getDateDebPhase().isBefore(currentDate) && ph.getDatePhasePrevue().isAfter(currentDate)
					|| ph.getDateDebPhase().isEqual(currentDate) && ph.getDatePhasePrevue().isAfter(currentDate)) {
				nbphasencours++;
			}
		});
		listphpro.forEach(p -> {
			if (p.getDatePhasePrevue().isBefore(currentDate)) {
				nbphasecloturé++;
			}
		});
		PrimeFaces.current().ajax().update("form");

	}
}
