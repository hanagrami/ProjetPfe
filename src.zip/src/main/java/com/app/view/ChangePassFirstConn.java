package com.app.view;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.app.domain.Habilitations;
import com.app.domain.Utilisateur;
import com.app.service.HabilitationService;
import com.app.service.ParametrageService;
import com.app.service.UserService;
import com.utils.BcriptEncoder;
import com.utils.JSFUtils;

import lombok.Getter;
import lombok.Setter;

@Component("changePassFirstConn")
@Setter
@Getter
@Scope("view")
public class ChangePassFirstConn implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Autowired
	private UserService userService;

	@Autowired
	private ParametrageService parametrageService;

	@Autowired
	private HabilitationService habilitationService;

	private String newPW1;
	private String newPW2;
	private Integer nbMax;
	private String msgCartePass;

	@PostConstruct
	public void onConstruct() {
		nbMax = Integer.parseInt(parametrageService.findByCode("PWD_MIN_LENGTH").getValVar());
		
		msgCartePass = JSFUtils.getMessage("regle_mot_passe", nbMax);
				
	}

	public void doChangePassword() {

		try {

			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

			Utilisateur utilisateur = userService.findByIdentifiant(authentication.getName()).get();

			String regex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{"+nbMax.toString()+",}$";
			if (!newPW1.equals(newPW2)) {

				JSFUtils.addErrorMessage("mot_de_passe_confirmation_errone", "mot_de_passe_confirmation_errone",
						"PWform");
			} else if (!Pattern.matches(regex, newPW1)) {

				JSFUtils.addErrorMessage("mot_de_passe_non_securise", "mot_de_passe_non_securise", "PWform", nbMax);

			} else {

				utilisateur.setUsrMotdepasse(BcriptEncoder.getEncoder(newPW1));
				utilisateur.setFlgPremConn(Boolean.FALSE);
				userService.updateUser(utilisateur);

				FacesContext fc = FacesContext.getCurrentInstance();
				UserBean userBean = fc.getApplication().evaluateExpressionGet(fc, "#{UserBean}", UserBean.class);
				userBean.chargerParametreGlobal(utilisateur.getUsrMatricule());

				List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();

				authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
				List<Habilitations> listHabilitation = habilitationService
						.findHabilitationByGrp(utilisateur.getGroupe());

				for (int i = 0; i < listHabilitation.size(); i++) {

					if (listHabilitation.get(i).getRessources().getType().equals("ITEM")) {
						authorities.add(
								new SimpleGrantedAuthority(listHabilitation.get(i).getRessources().getSecurityRole()));
					}
				}

				Authentication newAuth = new UsernamePasswordAuthenticationToken(authentication.getPrincipal(),
						authentication.getCredentials(), authorities);
				SecurityContextHolder.getContext().setAuthentication(newAuth);

				FacesContext.getCurrentInstance().getExternalContext().redirect("home.jsf");

			}

			newPW1 = "";
			newPW2 = "";
		} catch (Exception e) {
			Logger.getLogger(this.getClass()).error(e.getCause(), e);

			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "PWform");
		}
	}

}
