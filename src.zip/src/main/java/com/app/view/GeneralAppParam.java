package com.app.view;

import java.io.Serializable;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.app.service.ParametrageService;
import com.utils.JSFUtils;

import lombok.Data;

@Component("generalAppParam")
@Scope("application")
@Data
public class GeneralAppParam implements Serializable {
	final static Logger logger = Logger.getLogger(GeneralAppParam.class);

	private static final long serialVersionUID = 1L;
	@Autowired
	private ParametrageService parametrageService;
	private String nomApp;

	@PostConstruct
	public void onConstruct() {
		try {
			nomApp = parametrageService.findByCode("NOM_APP").getValVar();
		} catch (Exception e) {
			logger.error("Erreur s'est produite   ", e);

			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}

	}
}
