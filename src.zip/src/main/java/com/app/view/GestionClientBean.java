package com.app.view;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.app.domain.Client;
import com.app.service.ClientService;
import com.utils.JSFUtils;

import lombok.Getter;
import lombok.Setter;

@Component("clientMB")
@Scope("view")
@Getter
@Setter
public class GestionClientBean implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	final static Logger logger = Logger.getLogger(GestionClientBean.class);

	@Autowired
	private ClientService clientService;
	private List<Client> clients;
	private Client client;
	private Client selectClient;
	private boolean edit;
	private boolean consult;

	@PostConstruct
	public void init() {
		this.client = new Client();
		clients = clientService.findAll();
	}

	public void add() {
		try {
			this.client = new Client();
			edit = false;
			consult = false;
			PrimeFaces.current().ajax().update("formdialog");
			PrimeFaces.current().executeScript("PF('dialogajout').show()");
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erreur add client", e);
			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}
	}

	public void save() {
		try {
			String message = "";
			if (edit) {
				clientService.updateClient(client);
				message = JSFUtils.getMessage("client_modifie_avec_succes");
				JSFUtils.addInfoMessage(message, message, "form");

			} else {

				clientService.saveClient(client);
				message = JSFUtils.getMessage("client_ajoute_avec_succes");
				JSFUtils.addInfoMessage(message, message, "form");

			}

			clients = clientService.findAll();
			PrimeFaces.current().executeScript("PF('dialogajout').hide()");
			PrimeFaces.current().ajax().update("form");
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erreur ajouter client", e);
			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "formdialog");
		}
	}

	public void delete() {
		try {
			String message = "";
			this.clientService.deleteClient(this.selectClient);
			clients = clientService.findAll();
			PrimeFaces.current().ajax().update("form");
			message = JSFUtils.getMessage("client_supprime_avec_succes");
			JSFUtils.addInfoMessage(message, message, "form");

		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erreur supprimer client", e);
			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}

	}

	public void edit() {
		try {
			edit = true;
			consult = false;
			this.client = selectClient;
			PrimeFaces.current().ajax().update("formdialog");
			PrimeFaces.current().executeScript("PF('dialogajout').show()");

		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erreur edit client", e);
			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}

	}

	public void detailclient() {
		try {
			consult = true;
			edit = false;
			this.client = selectClient;
			PrimeFaces.current().ajax().update("formdialog");
			PrimeFaces.current().executeScript("PF('dialogajout').show()");

		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erreur consulter client", e);
			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}

	}

}
