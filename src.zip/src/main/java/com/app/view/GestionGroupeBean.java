package com.app.view;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.primefaces.model.CheckboxTreeNode;
import org.primefaces.model.TreeNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.app.domain.Groupe;
import com.app.domain.Ressources;
import com.app.domain.Utilisateur;
import com.app.service.GroupeService;
import com.app.service.HabilitationService;
import com.app.service.RessourceService;
import com.app.service.UserService;
import com.utils.JSFUtils;

import lombok.Getter;
import lombok.Setter;

@Component("gestionGroupeBean")
@Scope("view")
@Getter
@Setter

public class GestionGroupeBean implements Serializable {

	/**
	 * 
	 */
	final static Logger logger = Logger.getLogger(GestionGroupeBean.class);

	private static final long serialVersionUID = 1L;

	@Autowired
	private GroupeService groupeService;

	@Autowired
	private RessourceService ressourceService;

	@Autowired
	private HabilitationService habilitationService;

	@Autowired
	private UserService userService;

	private Groupe groupe;
	private Groupe selectedGroupe;
	private List<Groupe> listGroupe;
	private TreeNode treeRessource;
	private TreeNode[] selectedRessources;
	private boolean edit;
	private boolean consult;
	private String codeGroupe;
	private String libGroupe;
	private Utilisateur currentUser;

	@PostConstruct
	public void onConstruct() {
		FacesContext fc = FacesContext.getCurrentInstance();
		UserBean userBean = fc.getApplication().evaluateExpressionGet(fc, "#{UserBean}", UserBean.class);
		currentUser = userBean.getUtilisateur();
		listGroupe = groupeService.findAll();
	}

	public void initAddGroupe() {

		try {
			groupe = new Groupe();
			codeGroupe = "";
			libGroupe = "";
			edit = false;
			consult = false;
			setTreeRessource(renderTree(null));
			selectedRessources = null;
			PrimeFaces.current().executeScript("PF('addGroupeDialog').show()");

		} catch (Exception e) {
			logger.error("Erreur initAddGroupe ", e);

			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}

	}

	public void ajouterGroupe() {

		try {
			String message = "";

			groupe.setCodgrp(codeGroupe);

			groupe.setLibgrp(libGroupe);

			groupe.setCuticre(currentUser.getUsrMatricule());
			groupe.setDatecre(LocalDateTime.now());
			if (!edit) {

				Optional<Groupe> existGroupe = groupeService.findByCodeGroupe(groupe.getCodgrp());
				if (existGroupe.isPresent()) {
					message = JSFUtils.getMessage("code_groupe_deja_choisi");

					JSFUtils.addErrorMessage(message, message, "formAddGroupe");
				}
			}

			if (message.equals("")) {
				List<Ressources> listRessources = new ArrayList<Ressources>();
				for (int i = 0; i < selectedRessources.length; i++) {

					listRessources.add((Ressources) selectedRessources[i].getData());
					addParents(selectedRessources[i], listRessources);
				}

				if (edit) {

					groupeService.updateGroupe(groupe, listRessources);
					message = "groupe_modifie_avec_succes";
				} else {

					groupeService.saveGroupe(groupe, listRessources);
					message = "groupe_ajoute_avec_succes";

				}

				listGroupe = groupeService.findAll();

				PrimeFaces.current().executeScript("PF('addGroupeDialog').hide()");
				PrimeFaces.current().ajax().update("form");

				JSFUtils.addInfoMessage(message, message, "form");

			}
		} catch (Exception e) {
			logger.error("Erreur ajouterGroupe ", e);

			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "formAddGroupe");
		}
	}

	private void addParents(TreeNode node, List<Ressources> listRessources) {

		if (node.getParent() != null) {

			if ((!listRessources.contains(node.getParent().getData()))
					&& (((Ressources) node.getParent().getData()).getIdRessource() != null)) {

				listRessources.add((Ressources) node.getParent().getData());
			}

			addParents(node.getParent(), listRessources);
		}

	}

	public void supprimerGroupe() {
		try {
			List<Utilisateur> listUtilisateurGroupe = userService.findByGroupe(selectedGroupe);

			if (listUtilisateurGroupe != null && listUtilisateurGroupe.size() > 0) {

				JSFUtils.addErrorMessage("il_existe_des_utilisateurs_avec_ce_groupe",
						"il_existe_des_utilisateurs_avec_ce_groupe", "form");

			} else {

				groupeService.deleteGroupe(selectedGroupe);
				listGroupe = groupeService.findAll();

				JSFUtils.addInfoMessage("groupe_supprime_avec_succes", "groupe_supprime_avec_succes", "form");
			}
		} catch (Exception e) {
			logger.error("Erreur supprimerGroupe ", e);

			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}
	}

	public void initModifGroupe() {

		try {
			edit = true;
			consult = false;
			groupe = selectedGroupe;
			libGroupe = selectedGroupe.getLibgrp();
			codeGroupe = selectedGroupe.getCodgrp();
			List<Ressources> listRessources = habilitationService.findRessourceByGrp(groupe);
			treeRessource = renderTree(listRessources);
			PrimeFaces.current().executeScript("PF('addGroupeDialog').show()");
		} catch (Exception e) {
			logger.error("Erreur initModifGroupe ", e);

			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}
	}

	public void initDetailGroupe() {
		try {
			consult = true;
			edit = false;
			groupe = selectedGroupe;
			libGroupe = selectedGroupe.getLibgrp();
			codeGroupe = selectedGroupe.getCodgrp();
			List<Ressources> listRessources = habilitationService.findRessourceByGrp(groupe);
			treeRessource = renderTree(listRessources);
			PrimeFaces.current().executeScript("PF('addGroupeDialog').show()");

		} catch (Exception e) {
			logger.error("Erreur initDetailGroupe ", e);

			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}
	}

	private TreeNode renderTree(List<Ressources> listRessourceGroupe) {

		TreeNode tree = new CheckboxTreeNode(new Ressources(), null);
		buildTopTree(tree, listRessourceGroupe);
		tree.setExpanded(true);
		return tree;
	}

	private void buildTopTree(TreeNode root, List<Ressources> listRessourceGroupe) {

		List<Ressources> result;

		result = ressourceService.getRessourcesByQuery(null, null);
		Iterator<Ressources> iterator = result.iterator();
		while (iterator.hasNext()) {
			Ressources menu = (Ressources) iterator.next();
			if (isLeaf(menu.getIdRessource())) {
				TreeNode item = new CheckboxTreeNode(menu, root);
				if (listRessourceGroupe != null) {

					if (listRessourceGroupe.contains(menu)) {
						item.setSelected(true);
					}
				}

			} else {
				TreeNode item = new CheckboxTreeNode(menu, root);
				item.setExpanded(true);
				if (listRessourceGroupe != null) {

					if (listRessourceGroupe.contains(menu)) {
						item.setSelected(true);
					}
				}
				buildTree(menu.getIdRessource(), item, listRessourceGroupe);
			}

		}

	}

	private boolean isLeaf(Integer menuId) {

		boolean isLeaf = false;

		List<Ressources> result;
		result = ressourceService.getRessourcesByQuery(menuId, null);

		if (result.size() == 0) {

			isLeaf = true;
		}

		else {

			isLeaf = false;
		}
		return isLeaf;
	}

	private void buildTree(Integer menuId, TreeNode node, List<Ressources> listRessourceGroupe) {

		List<Ressources> result;
		result = ressourceService.getRessourcesByQuery(menuId, null);
		Iterator<Ressources> iterator = result.iterator();

		while (iterator.hasNext()) {
			Ressources menu = (Ressources) iterator.next();

			if (isLeaf(menu.getIdRessource())) // simple menu
			{
				TreeNode item = new CheckboxTreeNode(menu, node);
				if (listRessourceGroupe != null) {

					if (listRessourceGroupe.contains(menu)) {
						item.setSelected(true);
					}
				}

			} else {
				TreeNode item = new CheckboxTreeNode(menu, node);
				item.setExpanded(true);
				if (listRessourceGroupe != null) {

					if (listRessourceGroupe.contains(menu)) {
						item.setSelected(true);
					}
				}
				buildTree(menu.getIdRessource(), item, listRessourceGroupe);
			}
		}
	}

}
