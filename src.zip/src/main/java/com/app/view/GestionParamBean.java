package com.app.view;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.app.domain.Parametrage;
import com.app.domain.Utilisateur;
import com.app.service.ParametrageService;
import com.utils.JSFUtils;

import lombok.Getter;
import lombok.Setter;

@Component
@Scope("view")
@Getter
@Setter

public class GestionParamBean implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	final static Logger logger = Logger.getLogger(GestionParamBean.class);

	@Autowired
	private ParametrageService parametrageService;

	private List<Parametrage> listParam;
	private Parametrage selectedParam;
	private String valParam;
	private Utilisateur utilisateur;

	private Boolean edit;

	@PostConstruct
	public void onConstruct() {

		listParam = parametrageService.findAll();
		FacesContext fc = FacesContext.getCurrentInstance();
		UserBean userBean = fc.getApplication().evaluateExpressionGet(fc, "#{UserBean}", UserBean.class);
		setUtilisateur(userBean.getUtilisateur());
	}

	public void validerParam() {

		try {

			if (edit) {
				selectedParam.setCutimod(utilisateur.getUsrMatricule());
				selectedParam.setDatemod(LocalDateTime.now());
			}else {
				selectedParam.setCuticre(utilisateur.getUsrMatricule());
				selectedParam.setDatecre(LocalDateTime.now());
				selectedParam.setTypeApp("WEB");
			}
			selectedParam.setValVar(valParam);
			parametrageService.updateParametre(selectedParam);
			listParam = parametrageService.findAll();

			PrimeFaces.current().executeScript("PF('paramDialog').hide()");
			PrimeFaces.current().ajax().update("form");
			JSFUtils.addInfoMessage("parametre_modifie_avec_succes", "parametre_modifie_avec_succes", "form");
		} catch (Exception e) {
			logger.error("Erreur modifierParam ", e);

			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "formModifParam");
		}

	}

	public void initModifParam() {
		try {

			edit = Boolean.TRUE;
			valParam = selectedParam.getValVar();
			PrimeFaces.current().executeScript("PF('paramDialog').show()");

		} catch (Exception e) {
			logger.error("Erreur initModifParam ", e);

			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}

	}

	public void initAjoutParam() {
		try {

			edit = Boolean.FALSE;
			selectedParam = new Parametrage();
			valParam = null;
			PrimeFaces.current().executeScript("PF('paramDialog').show()");

		} catch (Exception e) {
			logger.error("Erreur initModifParam ", e);

			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}

	}

}
