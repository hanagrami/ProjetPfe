package com.app.view;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.app.domain.Phase;
import com.app.service.PhaseService;
import com.utils.JSFUtils;

import lombok.Getter;
import lombok.Setter;

@Component("phaseMB")
@Scope("view")
@Getter
@Setter
public class GestionPhaseBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	final static Logger logger = Logger.getLogger(GestionPhaseBean.class);

	@Autowired
	private PhaseService phaseService;
	private List<Phase> phases;
	private Phase phase;
	private Phase phaseSelected;
	private boolean edit;
	private boolean consult;

	@PostConstruct
	public void init() {
		phase = new Phase();
		phases = phaseService.findAll();
	}

	public void addphase() {
		try {
			phase = new Phase();
			edit = false;
			consult = false;
			PrimeFaces.current().ajax().update("formdialog");
			PrimeFaces.current().executeScript("PF('dialogajout').show()");

		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erreur addphase", e);
			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}
	}

	public void savephase() {
		try {
			String message = "";
			if (edit) {
				phaseService.updatePhase(phase);
				message = JSFUtils.getMessage("phase_modifier_avec_succées");
				JSFUtils.addInfoMessage(message, message, "form");
			} else {

				phaseService.savePhase(phase);
				message = JSFUtils.getMessage("phase_ajouter_avec_succées");
				JSFUtils.addInfoMessage(message, message, "form");
			}

			phases = phaseService.findAll();
			PrimeFaces.current().executeScript("PF('dialogajout').hide()");
			PrimeFaces.current().ajax().update("form");

		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erreur ajouter phase", e);
			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "formdialog");
		}

	}

	public void editphase() {
		try {
			phase = phaseSelected;
			edit = true;
			consult = false;
			PrimeFaces.current().ajax().update("formdialog");
			PrimeFaces.current().executeScript("PF('dialogajout').show()");

		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erreur edit phase", e);
			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}
	}

	public void deletephase() {
		try {

			String message = "";
			phaseService.deletePhase(phaseSelected);
			phases = phaseService.findAll();
			PrimeFaces.current().ajax().update("form");
			message = JSFUtils.getMessage("phase_supprimer_avec_succées");
			JSFUtils.addInfoMessage(message, message, "form");

		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erreur delete produit", e);
			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}

	}

	public void consultph() {
		try {

			edit = false;
			consult = true;
			phase = phaseSelected;
			PrimeFaces.current().ajax().update("formdialog");
			PrimeFaces.current().executeScript("PF('dialogajout').show()");

		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erreur consulter phase", e);
			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}
	}
}
