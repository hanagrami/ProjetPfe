package com.app.view;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.app.domain.Produit;
import com.app.domain.Projet;
import com.app.service.ProduitService;
import com.app.service.ProjetService;
import com.utils.JSFUtils;

import lombok.Getter;
import lombok.Setter;

@Component("produitMB")
@Scope("view")
@Getter
@Setter
public class GestionProduitBean implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	final static Logger logger = Logger.getLogger(GestionProduitBean.class);
	@Autowired
	private ProduitService produitService;
	@Autowired
	private ProjetService projetService;
	private List<Produit> produits;
	private Produit produit;
	private Produit produitselectionner;
	private boolean edit;
	private boolean consult;

	@PostConstruct
	public void init() {
		produit = new Produit();
		produits = produitService.findAll();
	}

	public void add() {
		try {
			this.produit = new Produit();
			edit = false;
			consult = false;
			PrimeFaces.current().ajax().update("formprod1");
			PrimeFaces.current().executeScript("PF('ajoutprod').show()");
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erreur add produit", e);
			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "formprod");
		}
	}

	public void save() {
		try {

			String message = "";

			if (edit) {
				produitService.updateProduit(produit);
				message = JSFUtils.getMessage("produit_modifie_avec_succes");
				JSFUtils.addInfoMessage(message, message, "form");

			} else {

				produitService.saveProduit(produit);
				message = JSFUtils.getMessage("produit_ajouter_avec_succées");
				JSFUtils.addInfoMessage(message, message, "form");

			}
			produits = produitService.findAll();
			PrimeFaces.current().executeScript("PF('ajoutprod').hide()");
			PrimeFaces.current().ajax().update("formprod");
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erreur ajouter produit", e);
			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "formprod1");
		}
	}

	public void delete() {
		try {
			List<Projet> listProjet = projetService.findByIdProduit(produitselectionner.getIdProduit());
			if (listProjet!=null) {
				JSFUtils.addErrorMessage("if_existe_des_projets_avec_ce_produit",
						"if_existe_des_projets_avec_ce_produit", "formprod");
			} else {
				String message = "";
				produitService.deleteProduit(produitselectionner);
				produits = produitService.findAll();
				PrimeFaces.current().ajax().update("formprod");
				message = JSFUtils.getMessage("produit_supprime_avec_succes");
				JSFUtils.addInfoMessage(message, message, "form");
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erreur supprimer produit", e);
			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "formprod");
		}
	}

	public void edit() {
		try {

			edit = true;
			consult = false;
			this.produit = produitselectionner;
			PrimeFaces.current().ajax().update("formprod1");
			PrimeFaces.current().executeScript("PF('ajoutprod').show()");
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erreur edit produit", e);
			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "formprod");
		}
	}

	public void consultproduit() {
		try {
			edit = false;
			consult = true;
			this.produit = produitselectionner;
			PrimeFaces.current().ajax().update("formprod1");
			PrimeFaces.current().executeScript("PF('ajoutprod').show()");
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erreur consulter produit", e);
			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "formprod");
		}
	}

}
