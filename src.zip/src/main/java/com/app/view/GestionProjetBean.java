package com.app.view;

import java.awt.Event;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Paths;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.file.UploadedFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import com.app.domain.Client;
import com.app.domain.Maintenance;
import com.app.domain.Phase;
import com.app.domain.Phase_Projet;
import com.app.domain.Produit;
import com.app.domain.Projet;
import com.app.domain.Projet_Ressource;
import com.app.domain.Utilisateur;
import com.app.service.ClientService;
import com.app.service.MaintenanceService;
import com.app.service.PhaseProjetService;
import com.app.service.PhaseService;
import com.app.service.ProduitService;
import com.app.service.ProjetRessourceService;
import com.app.service.ProjetService;
import com.app.service.UserService;
import com.lowagie.text.pdf.codec.Base64.OutputStream;
import com.utils.JSFUtils;
import lombok.Getter;
import lombok.Setter;

@Component("projetBean")
@Scope("view")
@Getter
@Setter
public class GestionProjetBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	final static Logger logger = Logger.getLogger(GestionProjetBean.class);

	@Autowired
	private ProjetService projetService;
	@Autowired
	private ProjetRessourceService projetressService;
	@Autowired
	private PhaseProjetService phaseprojetService;
	@Autowired
	private UserService userService;
	@Autowired
	private MaintenanceService maintenanceService;
	@Autowired
	private PhaseService phaseService;
	@Autowired
	private ClientService clientService;
	@Autowired
	private ProduitService produitService;

	private Client client;
	private List<Client> clients;
	// maintenance
	private List<Maintenance> maintenances;
	private Maintenance maintenance;
	private Maintenance maintenanceselected;

	// utilisateur
	private Utilisateur utilisateur;
	private List<Utilisateur> users;

	// projet
	private List<Projet> projetfiltred;
	private List<Projet> projets;
	private Projet projet;
	private Projet projetSelected;
	private boolean edit;

	HashMap<Integer, String> map = new HashMap<Integer, String>();

	// ressource
	private List<Projet_Ressource> projetRessources;
	private Projet_Ressource projetRessouSelected;
	private Projet_Ressource projetR;
	private List<Projet_Ressource> listeresspro = new ArrayList<Projet_Ressource>();

	private List<Phase_Projet> listephpro = new ArrayList<Phase_Projet>();
	// phaseprojet
	private List<Phase_Projet> phaseProjets;
	private Phase_Projet phaseprojetSelected;
	private Phase_Projet php;

	// phase
	private List<Phase> phases;
	private Phase phase;
	private Phase phaseSelected;

	private boolean disable = false;
	private boolean selected = false;
	private boolean afficher = false;
	private boolean consult;
	private Produit produit;
	private String idproduit;
	private String idclient;
	private List<Produit> produits;
	LocalDate currentDate = LocalDate.now();
	private SelectItem[] pv = { new SelectItem(1, "oui"), new SelectItem(0, "non") };
	private int pvPha = 0;
	private UploadedFile file;
	private Entry<Integer, String> mapentry;
	private int nbphasencours;
	private int nbphasecloturé;
	private int nbphaseatt;
	private int nbphase;
	private List<Event> events;

	@PostConstruct
	public void init() {
		projet = new Projet();
		projets = projetService.findAll();
		projetR = new Projet_Ressource();
		projetRessources = projetressService.findAll();
		php = new Phase_Projet();
		phaseProjets = phaseprojetService.findAll();
		utilisateur = new Utilisateur();
		users = userService.findAll();
		maintenance = new Maintenance();
		maintenances = maintenanceService.findAll();
		phase = new Phase();
		phases = phaseService.findAll();
		client = new Client();
		clients = clientService.findAll();
		produit = new Produit();
		produits = produitService.findAll();
		events = new ArrayList<>();
	}

	public void addprojet() {
		projet = new Projet();
		listephpro = new ArrayList<Phase_Projet>();
		listeresspro = new ArrayList<Projet_Ressource>();
		edit = false;
		consult = false;
		PrimeFaces.current().ajax().update("formdialog");
		PrimeFaces.current().executeScript("PF('dialogajout').show()");
	}

	public void saveprojet() throws IOException {
		String message = "";

		if (edit) {
			projet.setCutiMod(utilisateur.getUsrMatricule());
			projet.setDateMod(LocalDateTime.now());
			php.setCutiModPh(utilisateur.getUsrMatricule());
			php.setDateModPh(LocalDateTime.now());
			projetService.modifierprojet(projet, listeresspro, listephpro);

			message = JSFUtils.getMessage("projet_modifier_avec_succées");
			JSFUtils.addInfoMessage(message, message, "form");
		} else {
			if (file != null) {
				FileOutputStream outputStream1 = new FileOutputStream("C:\\GTI" + "\\" + file.getFileName());
				outputStream1.write((int) file.getSize());
				outputStream1.flush();
				outputStream1.close();
			}
			projet.setCutiCre(utilisateur.getUsrMatricule());
			projet.setDateCre(LocalDateTime.now());
			php.setCutiCreePh(utilisateur.getUsrMatricule());
			php.setDateCreePh(LocalDateTime.now());
			projetService.ajoutProjet(projet, listeresspro, listephpro);
			message = JSFUtils.getMessage("projet_ajouter_avec_succées");
			JSFUtils.addInfoMessage(message, message, "form");
		}
		projets = projetService.findAll();
		PrimeFaces.current().ajax().update("form");
		PrimeFaces.current().executeScript("PF('dialogajout').hide()");
		phaseprojetService.save(php, maintenance);
	}

	public void updateprojet() {
		edit = true;
		consult = false;
		projet = projetSelected;
		listeresspro = projetressService.findByIdProjet(projetSelected.getIdProjet());
		listephpro = phaseprojetService.findByIdProjet(projetSelected.getIdProjet());
		PrimeFaces.current().ajax().update("formdialog");
		PrimeFaces.current().executeScript("PF('dialogajout').show()");

	}

	public void consultprojet() {
		edit = false;
		consult = true;
		projet = projetSelected;
		listeresspro = projetressService.findByIdProjet(projetSelected.getIdProjet());
		listephpro = phaseprojetService.findByIdProjet(projetSelected.getIdProjet());
		PrimeFaces.current().ajax().update("formdialog");
		PrimeFaces.current().executeScript("PF('dialogajout').show()");

	}

	public void deleteprojet() {
		String message = "";
		projetService.deleteProjet(projetSelected);
		projets = projetService.findAll();
		PrimeFaces.current().ajax().update("form");
		message = JSFUtils.getMessage("projet_supprimer_avec_succées");
		JSFUtils.addInfoMessage(message, message, "form");
	}

	// ressource
	public void addRessourceProjet() {
		projetR = new Projet_Ressource();
		PrimeFaces.current().ajax().update("formressource");
		PrimeFaces.current().executeScript("PF('dialogajoutress').show()");
	}

	public void editRessourceProjet() {
		edit = true;
		projetR = projetRessouSelected;
		PrimeFaces.current().ajax().update("formressource");
		PrimeFaces.current().executeScript("PF('dialogajoutress').show()");

	}

	public void deleteRessourceProjet() {
		for (int i = 0; i < listeresspro.size(); i++) {
			listeresspro.remove(i);
			projetressService.deleteProjetRess(projetRessouSelected);
			String message = JSFUtils.getMessage("ressource_supprimer_avec_succée");
			JSFUtils.addInfoMessage(message, message, "formdialog");

		}

		PrimeFaces.current().ajax().update("formdialog");

	}

	public void listeP() {
		for (int i = 0; i < listeresspro.size(); i++) {
			listeresspro.get(i);
		}
	}

	public void ajout() {
		if (projetR.equals(projetRessouSelected)) {
			for (int i = 0; i < listeresspro.size(); i++) {
				listeresspro.remove(projetRessouSelected);
				listeresspro.add(i, projetR);
				String message = JSFUtils.getMessage("ressource_modifier_avec_succée");
				JSFUtils.addInfoMessage(message, message, "formdialog");

			}
		} else {
			listeresspro.add(projetR);
			String message = JSFUtils.getMessage("ressource_ajouter_avec_succée");
			JSFUtils.addInfoMessage(message, message, "formdialog");

		}
		PrimeFaces.current().executeScript("PF('dialogajoutress').hide()");
		PrimeFaces.current().ajax().update("formdialog");
	}

	// phaseprojet
	public void addphaseProjet() {
		php = new Phase_Projet();
		maintenance = new Maintenance();
		PrimeFaces.current().ajax().update("formdialogph");
		PrimeFaces.current().executeScript("PF('dialogajoutph').show()");
	}

	public void editphaseProjet() {
		edit = true;
		php = phaseprojetSelected;
		PrimeFaces.current().ajax().update("formdialogph");
		PrimeFaces.current().executeScript("PF('dialogajoutph').show()");

	}

	public void deletephaseProjet() {

		for (int i = 0; i < listephpro.size(); i++) {
			listephpro.remove(i);
			phaseprojetService.deletePhp(phaseprojetSelected);

		}
		PrimeFaces.current().ajax().update("formdialog");

	}

	// maintenance

	public void add() {
		maintenance = new Maintenance();
		PrimeFaces.current().ajax().update("formdialog");
		PrimeFaces.current().executeScript("PF('dialogajout').show()");
	}

	public void save() {

		String message = "";
		maintenanceService.saveMaint(maintenance);
		message = JSFUtils.getMessage("client_ajoute_avec_succes");
		JSFUtils.addInfoMessage(message, message, "form");

		maintenances = maintenanceService.findAll();
		PrimeFaces.current().executeScript("PF('dialogajout').hide()");
		PrimeFaces.current().ajax().update("form");
	}

	public void delete() {
		String message = "";
		maintenanceService.deleteMaint(maintenance);
		maintenances = maintenanceService.findAll();
		PrimeFaces.current().ajax().update("form");
		message = JSFUtils.getMessage("client_supprime_avec_succes");
		JSFUtils.addInfoMessage(message, message, "form");

	}

	public void edit() {
		maintenance = maintenanceselected;
		PrimeFaces.current().ajax().update("formdialog");
		PrimeFaces.current().executeScript("PF('dialogajout').show()");
	}

	public void select() {
		Phase p = phaseService.findById(php.getIdPhase()).get();
		if (p.getFlgmaint() == 1) {
			disable = true;
		} else {
			disable = false;
		}
		PrimeFaces.current().ajax().update("formdialogph");
	}

	public void file() {
		if (pvPha == 1) {
			afficher = true;
		} else {
			afficher = false;
		}
		PrimeFaces.current().ajax().update("formdialogph");
	}

	public List<Event> getEvents() {
		return events;
	}

	public static class Event {
		String status;
		int nbphase;

		public Event() {
		}

		public Event(String status, int nbphase) {
			this.status = status;
			this.nbphase = nbphase;

		}

		public void Event(String status, int nbphase) {
			this.status = status;
			this.nbphase = nbphase;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public int getNbphase() {
			return nbphase;
		}

		public void setNbphase(int nbphase) {
			this.nbphase = nbphase;
		}

	}

	public void listselect() {
		events = new ArrayList<>();
		nbphasencours = 0;
		nbphasecloturé = 0;
		nbphaseatt = 0;
		listephpro = new ArrayList<Phase_Projet>();
		if (projetService.findById(projetSelected.getIdProjet()) != null) {
			selected = true;
			listephpro = phaseprojetService.findByIdProjet(projetSelected.getIdProjet());
			listephpro.forEach(ph -> {
				// int nbphasencours = 0;
				// int nbphasecloturé = 0;
				// jour j<sys and fin>sys
				// jour j=sys and fin >sys
				// date deeb>sys date fin<date j
				// 01/11/2020 lel 30/112020 6/11/2020 encous
				// 01/11/2020 lel 30/112020 06/12/2020 cloture
				// 01/11/2020 lel 30/112020 01/09/2020

				if (ph.getDateDebPhase().isAfter(currentDate) && (ph.getDatePhasePrevue().isAfter(currentDate))) {
					nbphaseatt++;
				}

				else if (ph.getDateDebPhase().isBefore(currentDate) && ph.getDatePhasePrevue().isAfter(currentDate)) {
					nbphasencours++;

				} else if (ph.getDateDebPhase().isBefore(currentDate)
						&& ph.getDatePhasePrevue().isBefore(currentDate)) {
					nbphasecloturé++;

				}
			});
			events.add(new Event("pas commencé", nbphaseatt));
			events.add(new Event("encours", nbphasencours));
			events.add(new Event("cloturé", nbphasecloturé));
		} else {
			selected = false;
		}
		PrimeFaces.current().ajax().update("form");
	}

	public void upload(FileUploadEvent event) throws IOException {
		String path = "C:\\GTI";

		FacesMessage msg = new FacesMessage("Success! ", event.getFile().getFileName() + " is uploaded.");
		FacesContext.getCurrentInstance().addMessage(null, msg);
		String filename = FilenameUtils.getName(file.getFileName());
		InputStream is = event.getFile().getInputStream();
		OutputStream out = new OutputStream((java.io.OutputStream) file);
		byte[] b = new byte[(int) file.getSize()];
		int len;
		while ((len = is.read(b)) > 0)
			out.write(b, 0, len);
		is.close();
		out.close();

	}

	public void testdatephaseprec() throws IOException {
		if (listephpro.isEmpty()) {
			listephpro.add(php);
			PrimeFaces.current().executeScript("PF('dialogajoutph').hide()");
			String message = JSFUtils.getMessage("phase_ajouter_avec_succée");
			JSFUtils.addInfoMessage(message, message, "formdialog");
			PrimeFaces.current().ajax().update("formdialog");

		} else {

			Phase_Projet found = listephpro.stream()
					.filter(ph -> (ph.getDateDebPhase().isAfter(php.getDateDebPhase())
							&& ph.getDatePhasePrevue().isAfter(php.getDateDebPhase()))
							|| (ph.getDateDebPhase().isAfter(php.getDatePhasePrevue())
									&& ph.getDatePhasePrevue().isAfter(php.getDatePhasePrevue())))
					.findAny().orElse(null);
			if (found == null) {
				listephpro.add(php);
				PrimeFaces.current().executeScript("PF('dialogajoutph').hide()");
				String message = JSFUtils.getMessage("phase_ajouter_avec_succée");
				JSFUtils.addInfoMessage(message, message, "formdialog");
				PrimeFaces.current().ajax().update("formdialog");
			} else {
				String message = JSFUtils.getMessage("date_deja_utilisé_dans_la_phase_précédente");
				JSFUtils.addErrorMessage(message, message, "formdialogph");
			}
		}
		// phaseprojetService.save(php, maintenance);

	}
}
