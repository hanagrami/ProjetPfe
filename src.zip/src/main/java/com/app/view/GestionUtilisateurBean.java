package com.app.view;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.PrimeFaces;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Component;

import com.app.domain.Groupe;
import com.app.domain.Utilisateur;
import com.app.service.GroupeService;
import com.app.service.ParametrageService;
import com.app.service.UserService;
import com.utils.BcriptEncoder;
import com.utils.JSFUtils;

import lombok.Getter;
import lombok.Setter;

@Component("gestionUtilisateurBean")
@Scope("view")
@Getter
@Setter

public class GestionUtilisateurBean implements Serializable {

	final static Logger logger = Logger.getLogger(GestionUtilisateurBean.class);

	private static final long serialVersionUID = 1L;

	@Autowired
	private GroupeService groupeService;

	@Autowired
	private UserService userService;

	 

	@Autowired
	private ParametrageService parametrageService;

	private String codeGrp;

	private List<Groupe> listGroupe;

//	private List<UtilisateurMembre> listEnfants = new ArrayList<UtilisateurMembre>();
	private List<Utilisateur> listUtilisateur;
	private List<Utilisateur> listfiltredUtilisateur;
	private Utilisateur utilisateur;
	private Utilisateur currentUser;
	 
	private Groupe groupe;
	private boolean disable;
	private boolean edit;
	private boolean editEnfant = false;
	private boolean consult;
	private Integer nbEnfant;
	private Long situationFam;
	private Long stage;
	private String nouveauMatricule;
 
	@PostConstruct
	public void onConstruct() {

		listGroupe = groupeService.findAll();

		List<String> FlgStatuts = new ArrayList<String>();
		FlgStatuts.add("A");
		FlgStatuts.add("I");
		listUtilisateur = userService.findByFlgStatutIn(FlgStatuts);
		utilisateur = new Utilisateur();
		 

		FacesContext fc = FacesContext.getCurrentInstance();
		UserBean userBean = fc.getApplication().evaluateExpressionGet(fc, "#{UserBean}", UserBean.class);
		currentUser = userBean.getUtilisateur();

	}

	public void initAddUser() {

		try {
			utilisateur = new Utilisateur();
			
			utilisateur.setFlgSuspendu(Boolean.FALSE);

			codeGrp = null;
			edit = false;
			setConsult(false);

			PrimeFaces.current().executeScript("PF('addUserDialog').show()");

		} catch (Exception e) {
			logger.error("Erreur initAddUser ", e);

			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}
	}

	public void ajouterUser() {
		try {

			String message = "";

			utilisateur.setGroupe(groupeService.findByCodeGroupe(codeGrp).get());
			if (!edit) {

				Optional<Utilisateur> existUser = userService.findByIdentifiant(utilisateur.getUsrMatricule());
				if (existUser.isPresent() == true) {
					message = JSFUtils.getMessage("identifiant_utilisateur_deja_choisi");
					JSFUtils.addErrorMessage(message, message, "formAddUser");
				}

			}

	 
			if (message.equals("")) {

				if (edit) {

					utilisateur.setUsermod(currentUser.getUsrMatricule());
					utilisateur.setDatemod(LocalDateTime.now());
					//utilisateur.setSituationFam(situationFam);
					//utilisateur.setNbEnfant(nbEnfant);
					userService.updateUser(utilisateur);
				//	userService.update(utilisateur, listEnfants, conjoint);

					message = JSFUtils.getMessage("utilisateur_modifie_avec_succes");
					JSFUtils.addInfoMessage(message, message, "form");
				}

				else {
					utilisateur.setUsercre(currentUser.getUsrMatricule());
					utilisateur.setDatecre(LocalDateTime.now());
					utilisateur.setFlgStatut("A");
					utilisateur.setFlgPremConn(Boolean.TRUE);
					//utilisateur.setSoldeConge(BigDecimal.ZERO);
					//utilisateur.setSituationFam(situationFam);
					//utilisateur.setNbEnfant(nbEnfant);
					utilisateur.setUsrMotdepasse(
							BcriptEncoder.getEncoder(parametrageService.findByCode("DEFAULT_PASSWORD").getValVar()));

				 userService.updateUser(utilisateur);

					message = JSFUtils.getMessage("utilisateur_ajoute_avec_succes");
					JSFUtils.addInfoMessage(message, message, "form");
				}

				listUtilisateur = userService.findAll();

				PrimeFaces.current().executeScript("PF('addUserDialog').hide()");
				PrimeFaces.current().ajax().update("form");

			}
		}

		catch (Exception e) {
			logger.error("Erreur ajouterUser ", e);
			if (e instanceof DataIntegrityViolationException)
				JSFUtils.addErrorMessage("enfant_deja_utilise", "enfant_deja_utilise", "formAddUser");
			else
				JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "formAddUser");

		}

	}

	public void initModifUser() {
		try {
			edit = true;
			setConsult(false);
			codeGrp = utilisateur.getGroupe().getCodgrp();
			//nbEnfant = utilisateur.getNbEnfant();
			//situationFam = utilisateur.getSituationFam();
		 

			PrimeFaces.current().executeScript("PF('addUserDialog').show()");

		} catch (Exception e) {
			logger.error("Erreur initModifUser ", e);

			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}
	}

	public void initDetailUser() {
		try {
			setConsult(true);
			edit = false;
			codeGrp = utilisateur.getGroupe().getCodgrp();
			//nbEnfant = utilisateur.getNbEnfant();
			//situationFam = utilisateur.getSituationFam();
		 

			PrimeFaces.current().executeScript("PF('addUserDialog').show()");

		} catch (Exception e) {
			logger.error("Erreur initDetailUser ", e);

			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}
	}

	public void debloquerUser() {
		try {
			String message = "";
			utilisateur.setUsermod(currentUser.getUsrMatricule());
			utilisateur.setDatemod(LocalDateTime.now());
			utilisateur.setFlgSuspendu(Boolean.FALSE);
			utilisateur.setNbErr(0);
			userService.updateUser(utilisateur);
			listUtilisateur = userService.findAll();
			message = JSFUtils.getMessage("utilisateur_debloque_avec_succes");
			JSFUtils.addInfoMessage(message, message, "form");

		} catch (Exception e) {
			logger.error("Erreur debloquerUser ", e);

			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}
	}

	public void bloquerUser() {
		try {

			String message = "";
			utilisateur.setUsermod(currentUser.getUsrMatricule());
			utilisateur.setDatemod(LocalDateTime.now());
			utilisateur.setFlgSuspendu(Boolean.TRUE);
			userService.updateUser(utilisateur);
			listUtilisateur = userService.findAll();
			message = JSFUtils.getMessage("utilisateur_bloque_avec_succes");
			JSFUtils.addInfoMessage(message, message, "form");

		} catch (Exception e) {
			logger.error("Erreur bloquerUser ", e);

			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}
	}

	public void initPassUser() {
		try {
			String message = "";
			utilisateur.setUsermod(currentUser.getUsrMatricule());
			utilisateur.setDatemod(LocalDateTime.now());
			utilisateur.setUsrMotdepasse(
					BcriptEncoder.getEncoder(parametrageService.findByCode("DEFAULT_PASSWORD").getValVar()));

			utilisateur.setFlgPremConn(Boolean.TRUE);
			userService.updateUser(utilisateur);
			listUtilisateur = userService.findAll();
			message = JSFUtils.getMessage("mot_de_passe_initialise_avec_succes");
			JSFUtils.addInfoMessage(message, message, "form");

		} catch (Exception e) {
			logger.error("Erreur initPassUser ", e);

			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}
	}

	public void desactiverrUser() {
		try {
			String message = "";
			utilisateur.setFlgStatut("I");
			utilisateur.setFlgSuspendu(Boolean.FALSE);

			utilisateur.setUsermod(currentUser.getUsrMatricule());
			utilisateur.setDatemod(LocalDateTime.now());

			userService.updateUser(utilisateur);
			listUtilisateur = userService.findAll();
			message = JSFUtils.getMessage("utilisateur_desactive_avec_succes");
			JSFUtils.addInfoMessage(message, message, "form");

		} catch (Exception e) {
			logger.error("Erreur desactiverUser ", e);

			JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		}
	}

	//public void onChangeSitFam() {

	//	nbEnfant = null;
	 

	//}

	//public void initAjoutEnfant() {
	//	editEnfant = false;
	 
	//	PrimeFaces.current().executeScript("PF('addEnfantDial').show()");

	//}

	//public void initList() {

	//	if (nbEnfant == 0) {

			 

		//}
	//}

	//public void ajouterEnfant() {

	//	try {
		//	String message = "";

			//if (editEnfant) {

				 
			//	editEnfant = false;

			//	message = JSFUtils.getMessage("enfant_modifie_avec_succes");
				//JSFUtils.addInfoMessage(message, message, "formAddUser");

		//	}

			//else {

			 

				//PrimeFaces.current().executeScript("PF('addEnfantDial').hide()");
				//PrimeFaces.current().ajax().update("formAddUser:dataEnfants");

			//}
		//} catch (Exception e) {
			//logger.error("Erreur ajout Enfant ", e);
//
			//JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		//}

	//}

	//public void deleteAction() {

		 
	//	PrimeFaces.current().ajax().update("formAddUser:dataEnfants");
		//JSFUtils.addInfoMessage("enfant_supprime_avec_succes", "enfant_supprime_avec_succes", "formAddUser");
	//}

	//public void initModifEnfant() {
	//	try {
		//	editEnfant = true;
			//PrimeFaces.current().executeScript("PF('addEnfantDial').show()");

		//} catch (Exception e) {
		//	logger.error("Erreur initModifEnfant ", e);

			//JSFUtils.addErrorMessage("erreur_produite", "erreur_produite", "form");
		//}
	//}

}