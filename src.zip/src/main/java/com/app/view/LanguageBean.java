package com.app.view;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Component("language")
@Scope("session")
@Getter
@Setter

public class LanguageBean implements Serializable {
	private static final long serialVersionUID = 1L;
	

	
	private Locale locale;

	private String localeCode;
	private String newLocaleValue;

	@PostConstruct
	public void onConstruct() {

		locale = new Locale("fr");

	}

	private static Map<String, Object> countries;
	static {
		countries = new LinkedHashMap<String, Object>();
		countries.put("French", Locale.FRENCH); // label, value
		countries.put("English", Locale.ENGLISH); // label, value
	}

	public Map<String, Object> getCountriesInMap() {
		return countries;
	}

	public void changeLanguage(String language) {
		setLocale(new Locale(language));
		FacesContext.getCurrentInstance().getViewRoot().setLocale(new Locale(language));
	}

	// value change event listener
	public void countryLocaleCodeChanged(ValueChangeEvent e) {

		String newLocaleValue = e.getNewValue().toString();

		// loop country map to compare the locale code
		for (Map.Entry<String, Object> entry : countries.entrySet()) {

			if (entry.getValue().toString().equals(newLocaleValue)) {

				FacesContext.getCurrentInstance().getViewRoot().setLocale((Locale) entry.getValue());

			}
		}
	}

	public void changeLocale() {

		// loop country map to compare the locale code
		for (Map.Entry<String, Object> entry : countries.entrySet()) {

			if (entry.getKey().toString().equals(newLocaleValue)) {

				setLocale((Locale) entry.getValue());
				FacesContext.getCurrentInstance().getViewRoot().setLocale((Locale) entry.getValue());

			}
		}
	}

	

}