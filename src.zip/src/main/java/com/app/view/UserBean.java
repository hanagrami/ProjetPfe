package com.app.view;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.primefaces.model.menu.MenuModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Component;

import com.app.domain.Habilitations;
import com.app.domain.Ressources;
import com.app.domain.Utilisateur;
import com.app.service.HabilitationService;
import com.app.service.MenuFactoryService;
import com.app.service.ParametrageService;
import com.app.service.UserService;
import com.utils.BcriptEncoder;
import com.utils.JSFUtils;

import lombok.Getter;
import lombok.Setter;

@Component("UserBean")
@Scope("session")
@Getter
@Setter

public class UserBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Autowired
	private UserService userService;

	@Autowired
	private HabilitationService habilitationService;
	@Autowired
	private ParametrageService parametrageService;
	@Autowired
	private MenuFactoryService menuFactoryService;
	private TimeZone timezone;
	private Utilisateur utilisateur;
	private MenuModel menuBarModel;
	private String today;
	private String ancienPass;
	private String newPass;
	private String confPass;
	private String minLength;

	final static Logger logger = Logger.getLogger(UserBean.class);

	@PostConstruct
	public void onConstruct() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy");
		today = LocalDate.now().format(formatter);
		timezone = TimeZone.getTimeZone("GMT+1");
		minLength = parametrageService.findByCode("PWD_MIN_LENGTH").getValVar();
	}

	public void chargerParametreGlobal(String userName) {

		/* Chargement Utilisateur */
		utilisateur = userService.findByIdentifiant(userName).get();

		if (utilisateur.getNbErr() != null && utilisateur.getNbErr() > 0) {
			utilisateur.setNbErr(0);

		}
		userService.updateUser(utilisateur);

		/* Chargement menu */
		List<Habilitations> listHabilitation = habilitationService.findHabilitationByGrp(utilisateur.getGroupe());

		List<Ressources> listRessources = new ArrayList<Ressources>();

		for (int i = 0; i < listHabilitation.size(); i++) {

			listRessources.add(listHabilitation.get(i).getRessources());

		}
		menuBarModel = menuFactoryService.buildTopMenu(listRessources);

	}

	public void changePass() {
		try {

			Boolean checkAncienPass = BCrypt.checkpw(ancienPass, utilisateur.getUsrMotdepasse());

			if (checkAncienPass) {

				String regex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{" + minLength.toString()
						+ ",}$";
				if (!newPass.equals(confPass)) {

					JSFUtils.addErrorMessage("mot_de_passe_confirmation_errone", "mot_de_passe_confirmation_errone",
							"PWform");
				} else if (!Pattern.matches(regex, newPass)) {

					JSFUtils.addErrorMessage("mot_de_passe_non_securise", "mot_de_passe_non_securise", "PWform",
							minLength);

				} else {
					utilisateur.setUsrMotdepasse(BcriptEncoder.getEncoder(newPass));
					userService.updateUser(utilisateur);

					JSFUtils.addInfoMessage("mot_de_passe_modif_avec_succ", "mot_de_passe_modif_avec_succ", ":form");
				}

			} else {

				JSFUtils.addErrorMessage("ancien_mot_de_passe_erroné", "ancien_mot_de_passe_erroné", ":form");
			}

			ancienPass = null;
			newPass = null;
			confPass = null;

		} catch (

		Exception e) {
			Logger.getLogger(this.getClass()).error("Error was occured when changing password", e);
		}
	}

}
