package com.repository;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaQuery;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.java.InputProcedure;

public interface MyRepository<T, ID extends Serializable> extends JpaRepository<T, ID> {

	public List<T> findByQuery(String query, List<Object> paramList, Class<T> entityClass);

	public BigDecimal findBigDecimalByQuery(String query, List<Object> paramList);

	public Map callOracleProcedure(String catalogName, String procedureName, List<InputProcedure> listParams);

	public Object callOracleFunction(String procName, List<Object> paramList, Integer sqlReturnType, String type);

	public List<T> callCriteriaQuer(CriteriaQuery<T> criteriaQuery);

	Object callStoredFunction(String funcNme, List<Object> paramList);

	public List<Map<String, Object>> getResultOfQuery(String queryString, List<Object> paramList);
}