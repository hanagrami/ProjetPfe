package com.repository;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaQuery;
import javax.sql.DataSource;

import org.hibernate.Session;
import org.hibernate.query.internal.NativeQueryImpl;
import org.hibernate.transform.AliasToEntityMapResultTransformer;
import org.springframework.data.jdbc.support.oracle.SqlReturnSqlData;
import org.springframework.data.jpa.repository.support.JpaEntityInformation;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.SqlReturnType;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.orm.jpa.EntityManagerFactoryInfo;

import com.app.java.AbstractTypeValue;
import com.app.java.InputProcedure;

@NoRepositoryBean
public class MyRepositoryImpl<T, ID extends Serializable> extends SimpleJpaRepository<T, ID>
		implements MyRepository<T, ID> {
	private final EntityManager entityManager;

	public MyRepositoryImpl(JpaEntityInformation entityInformation, EntityManager entityManager) {
		super(entityInformation, entityManager);
		// Keep the EntityManager around to used from the newly introduced
		// methods.
		this.entityManager = entityManager;
	}

	@Override
	public List<T> findByQuery(String query, List<Object> paramList, Class<T> entityClass) {
		List<T> results = new ArrayList<T>();
		Query q = entityManager.createNativeQuery(query, entityClass);

		for (int i = 0; i < paramList.size(); i++) {

			q.setParameter((i + 1), paramList.get(i));
		}
		results = q.getResultList();
		return results;

	}

	@SuppressWarnings("unchecked")
	@Override
	public Map callOracleProcedure(String catalogName, String procedureName, List<InputProcedure> listParams) {

		try {

			DataSource dataSource = ((EntityManagerFactoryInfo) entityManager.getEntityManagerFactory())
					.getDataSource();

			JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
			jdbcTemplate.setResultsMapCaseInsensitive(true);

			// Convert o_c_book SYS_REFCURSOR to List<Book>
			SimpleJdbcCall simpleJdbcCallRefCursor = new SimpleJdbcCall(jdbcTemplate).withCatalogName(catalogName)
					.withProcedureName(procedureName);

			int i = 0;
			for (i = 0; i < listParams.size(); i++) {

				switch (listParams.get(i).getTypeParam()) {

				case "IN":

					if (listParams.get(i).getSqlType() == 2003) {

						simpleJdbcCallRefCursor.declareParameters(new SqlParameter(listParams.get(i).getNomParam(),
								listParams.get(i).getSqlType(), listParams.get(i).getArrayTypeName()));

					} else if (listParams.get(i).getSqlType() == 2002) {
						simpleJdbcCallRefCursor.declareParameters(new SqlParameter(listParams.get(i).getNomParam(),
								listParams.get(i).getSqlType(), listParams.get(i).getObjectTypeName()));

					} else {

						simpleJdbcCallRefCursor.declareParameters(
								new SqlParameter(listParams.get(i).getNomParam(), listParams.get(i).getSqlType()));

					}
					break;
				case "OUT":

					if (listParams.get(i).getSqlType() == 2003) {

						simpleJdbcCallRefCursor.declareParameters(
								new SqlOutParameter(listParams.get(i).getNomParam(), listParams.get(i).getSqlType(),
										listParams.get(i).getArrayTypeName(), new SqlReturnType() {

											@Override
											public Object getTypeValue(CallableStatement cs, int paramIndex,
													int sqlType, String typeName) throws SQLException {
												Connection connection = cs.getConnection();
												Map<String, Class<?>> typeMap = connection.getTypeMap();
												typeMap.put(listParams.get(paramIndex - 1).getObjectTypeName(),
														listParams.get(paramIndex - 1).getClassObjectType());
												return cs.getObject(paramIndex);
											}
										}));

					} else if (listParams.get(i).getSqlType() == 2002) {
						simpleJdbcCallRefCursor.declareParameters(new SqlOutParameter(listParams.get(i).getNomParam(),
								listParams.get(i).getSqlType(), listParams.get(i).getObjectTypeName(),
								new SqlReturnSqlData(listParams.get(i).getClassObjectType())));

					} else {

						simpleJdbcCallRefCursor.declareParameters(
								new SqlParameter(listParams.get(i).getNomParam(), listParams.get(i).getSqlType()));

					}

					break;
				default:
					break;

				}
			}

			MapSqlParameterSource map = new MapSqlParameterSource();
			for (i = 0; i < listParams.size(); i++) {

				if (listParams.get(i).getTypeParam() == "IN") {
					if (listParams.get(i).getSqlType() == 2003) {

						map.addValue(listParams.get(i).getNomParam(), AbstractTypeValue.forClass(
								listParams.get(i).getClassObjectType(), listParams.get(i).getValueParamArray()));
					} else {

						map.addValue(listParams.get(i).getNomParam(), listParams.get(i).getValueParam());
					}
				}
			}

			SqlParameterSource in = map;

			Map out = simpleJdbcCallRefCursor.execute(in);

			return out;

		} catch (Exception e) {

			throw e;
		}

	}

	@Override
	public Object callOracleFunction(String funcName, List<Object> paramList, Integer sqlReturnType, String typeName) {

		try {
			String query = "{? = call " + funcName;

			if (paramList != null && paramList.size() > 0)
				query = query + "(";
			for (int i = 0; i < paramList.size(); i++) {

				if (i == (paramList.size() - 1)) {
					query = query + "?";
				} else {

					query = query + "?,";
				}
			}
			if (paramList != null && paramList.size() > 0)
				query = query + ")";
			query = query + " }";

			String callName = query;
			Session session = entityManager.unwrap(Session.class);

			Object commentCount = session.doReturningWork(connection -> {
				try (CallableStatement function = connection.prepareCall(callName)) {

					if (typeName.length() == 0) {
						function.registerOutParameter(1, sqlReturnType);
					} else {
						function.registerOutParameter(1, sqlReturnType, typeName);
					}
					if (paramList != null) {
						// 3. Loop over values for the bind variables passed in,
						// if any
						for (int i = 0; i < paramList.size(); i++) {
							// 4. Set the value of user-supplied bind vars in
							// the stmt
							function.setObject(i + 2, paramList.get(i));
						}
					}
					function.executeUpdate();
					return function.getObject(1);
				}
			});

			return commentCount;

		} catch (Exception e) {

			throw e;
		}
	}

	@Override
	public List<T> callCriteriaQuer(CriteriaQuery<T> criteriaQuery) {
		List<T> results = entityManager.createQuery(criteriaQuery).getResultList();
		return results;

	}

	@Override
	public BigDecimal findBigDecimalByQuery(String query, List<Object> paramList) {
		Query q = entityManager.createNativeQuery(query);

		for (int i = 0; i < paramList.size(); i++) {

			q.setParameter((i + 1), paramList.get(i));
		}

		if (q.getResultStream().findFirst().isPresent())
			return new BigDecimal(((Number) q.getResultStream().findFirst().get()).doubleValue());

		return null;
	}

	@Override
	public Object callStoredFunction(String funcNme, List<Object> paramList) {

		String query = "SELECT " + funcNme + "(";

		for (int i = 0; i < paramList.size(); i++) {

			if (i == (paramList.size() - 1)) {
				query = query + "?";
			} else {

				query = query + "?,";
			}
		}

		query = query + ") FROM DUAL";

		Query q = entityManager.createNativeQuery(query);

		for (int i = 0; i < paramList.size(); i++) {

			q.setParameter((i + 1), paramList.get(i));
		}

		Object returnFunc = q.getSingleResult();

		return returnFunc;

	}

	@Override
	public List<Map<String, Object>> getResultOfQuery(String queryString, List<Object> paramList) {

		Query query = entityManager.createNativeQuery(queryString);
		for (int i = 0; i < paramList.size(); i++)
			query.setParameter((i + 1), paramList.get(i));
		NativeQueryImpl nativeQuery = (NativeQueryImpl) query;
		nativeQuery.setResultTransformer(AliasToEntityMapResultTransformer.INSTANCE);

		return nativeQuery.getResultList();

	}

}
