package com.utils;

public interface ErrorCode {
	int getNumber();
}
