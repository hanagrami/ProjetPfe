package com.utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletContext;
import javax.sql.DataSource;

import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRXlsExporter;
import net.sf.jasperreports.export.Exporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;

public class GtiReport {

	public static byte[] genReport(String reportFileName, Map<String, Object> parameters, String reportFormat)
			throws Exception {

		
		Context initContext = new InitialContext();
		DataSource ds = null;
		try {
			Context envContext = (Context) initContext.lookup("java:/comp/env");
			ds = (DataSource) envContext.lookup("jdbc/ProjetConsomme_DS");
		} catch (Exception e) {
			InitialContext ctx = new InitialContext();
			ds = (DataSource) ctx.lookup("jdbc/ProjetConsomme_DS");
		}
		Connection conn = ds.getConnection();

		FacesContext context = FacesContext.getCurrentInstance();
		ServletContext servletContext = (ServletContext) context.getExternalContext().getContext();

		parameters.put("SUBREPORT_DIR", servletContext.getRealPath("/reports/") + "\\");
		String webRoot = servletContext.getRealPath("/");
		File file = new File(webRoot + "reports");
		FileInputStream fileInputStream = new FileInputStream(new File(file, reportFileName + ".jasper"));
		JasperPrint jasperPrint = JasperFillManager.fillReport(fileInputStream, parameters, conn);

		ByteArrayOutputStream Report = new ByteArrayOutputStream();
		
		Exporter exporter = null;
		if (reportFormat.toUpperCase().equals("PDF")) {
			exporter = new JRPdfExporter();
		} else {
			exporter = new JRXlsExporter();
		}
		exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
		exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(Report));

        
		exporter.exportReport();
		// Send response
		byte[] bytes = Report.toByteArray();
		conn.close();

		return bytes;

	}

}
