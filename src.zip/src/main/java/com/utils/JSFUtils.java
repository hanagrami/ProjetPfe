package com.utils;

import java.text.MessageFormat;
import java.util.List;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

public class JSFUtils {

	private static ResourceBundle bundle;

	public static String getMessage(String chave) {
		return getResourceBundle().getString(chave);
	}

	public static String getMessage(String chave, Object... parametros) {
		chave = getResourceBundle().getString(chave);
		return MessageFormat.format(chave, parametros);
	}

	public static ResourceBundle getResourceBundle() {
		FacesContext context = FacesContext.getCurrentInstance();
		bundle = context.getApplication().getResourceBundle(context, "msgs");
		return bundle;
	}

	public static void addErrorMessages(List<String> messages) {
		for (String message : messages) {
			addErrorMessage(message, "", null);
		}
	}

	public static void addErrorMessage(String msg, String detail, String messageComponent) {

		try {
			msg = getResourceBundle().getString(msg);

		} catch (Exception e) {

		}
		try {
			detail = getResourceBundle().getString(detail);

		} catch (Exception e) {

		}
		FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, detail);
		FacesContext.getCurrentInstance().addMessage(messageComponent, facesMsg);
	}

	public static void addInfoMessage(String msg, String detail, String messageComponent) {

		try {
			msg = getResourceBundle().getString(msg);

		} catch (Exception e) {

		}
		try {
			detail = getResourceBundle().getString(detail);

		} catch (Exception e) {

		}
		FacesContext.getCurrentInstance().addMessage(messageComponent,
				new FacesMessage(FacesMessage.SEVERITY_INFO, msg, detail));

	}



	public static void addWarningMessage(String msg, String detail, String messageComponent) {
		try {
			msg = getResourceBundle().getString(msg);

		} catch (Exception e) {

		}
		try {
			detail = getResourceBundle().getString(detail);

		} catch (Exception e) {

		}
		FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, msg, detail);
		FacesContext.getCurrentInstance().addMessage(messageComponent, facesMsg);
	}

	
	public static void addErrorMessage(String msg, String detail, String messageComponent,Object... parametros) {
		try {
			msg = getMessage(msg,parametros);

		} catch (Exception e) {

		}
		try {
			detail = getMessage(detail,parametros);

		} catch (Exception e) {

		}
		FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, detail);
		FacesContext.getCurrentInstance().addMessage(messageComponent, facesMsg);
	}

	public static void addInfoMessage(String msg, String detail, String messageComponent,Object... parametros) {
		try {
			msg = getMessage(msg,parametros);

		} catch (Exception e) {

		}
		try {
			detail = getMessage(detail,parametros);

		} catch (Exception e) {

		}
		FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, detail);
		FacesContext.getCurrentInstance().addMessage(messageComponent, facesMsg);
	}
	public static void addWarningMessage(String msg, String detail, String messageComponent,Object... parametros) {
		try {
			msg = getMessage(msg,parametros);

		} catch (Exception e) {

		}
		try {
			detail = getMessage(detail,parametros);

		} catch (Exception e) {

		}
		FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_WARN, msg, detail);
		FacesContext.getCurrentInstance().addMessage(messageComponent, facesMsg);
	}

}
