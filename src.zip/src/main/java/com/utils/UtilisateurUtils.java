package com.utils;

public class UtilisateurUtils {

	
	
	public static String getMatriculePaie(String matricule) {
	
		String matriculeFinal="";
		
		if(matricule.charAt(0)=='4' & matricule.charAt(1)=='0')
			
			 {matriculeFinal=matricule.substring(2);}
		
		
		else {
			matriculeFinal=matricule.substring(1);
		}
		
		
		return matriculeFinal;
		
		
	}
}
